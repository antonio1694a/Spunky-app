# Native Android APK & One UI Widget Setup Guide

This guide allows you to compile **Spunky Sun Chasing** into an authentic native Android APK featuring genuine **Samsung One UI Home Screen Widgets** (4x2 & 2x2).

---

## Option A: One-Shot Prompt for Cursor / Claude Code

If you open this project in **[Cursor](https://www.cursor.com)** or **Claude Code**, simply paste this prompt:

> *"Please set up Capacitor Android for this project, copy the native widget files from `/android-native` into `android/app/src/main`, register `SolisWidgetProvider` in `AndroidManifest.xml`, and compile the debug APK using `./gradlew assembleDebug`."*

The AI will execute the setup and generate your `.apk` automatically.

---

## Option B: Run in 3 Minutes (Terminal / Android Studio)

### Step 1: Install Capacitor Android
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npm run build
npx cap add android
npx cap sync
```

### Step 2: Copy Native Widget Files into the Android Project
Move the pre-configured files from `android-native/` into your Android directory:

1. **Kotlin Provider**:
   Copy `android-native/SolisWidgetProvider.kt` into:
   `android/app/src/main/java/com/spunkysun/chasing/SolisWidgetProvider.kt`

2. **Widget Layout**:
   Copy `android-native/widget_layout_4x2.xml` into:
   `android/app/src/main/res/layout/widget_layout_4x2.xml`

3. **One UI Background**:
   Copy `android-native/widget_bg_oneui.xml` into:
   `android/app/src/main/res/drawable/widget_bg_oneui.xml`

4. **Widget Metadata**:
   Copy `android-native/widget_info_4x2.xml` into:
   `android/app/src/main/res/xml/widget_info_4x2.xml`

### Step 3: Register in AndroidManifest.xml
Open `android/app/src/main/AndroidManifest.xml` and paste this inside `<application> ... </application>`:

```xml
<receiver
    android:name=".SolisWidgetProvider"
    android:exported="true"
    android:label="Spunky Sun Hub">
    <intent-filter>
        <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
        <action android:name="com.spunkysun.chasing.WIDGET_UPDATE" />
    </intent-filter>
    <meta-data
        android:name="android.appwidget.provider"
        android:resource="@xml/widget_info_4x2" />
</receiver>
```

### Step 4: Build the APK
```bash
cd android
./gradlew assembleDebug
```

Your compiled `.apk` will be located at:
`android/app/build/outputs/apk/debug/app-debug.apk`

Transfer it to your Galaxy S24 Ultra, tap to install, and long-press your home screen: **Spunky Sun Hub** will be right there in your native Samsung One UI widget menu!
