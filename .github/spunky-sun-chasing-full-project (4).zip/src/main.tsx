import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(<App />);

// Register Service Worker for PWA / Android WebAPK install eligibility
if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((reg) => {
        console.log('Solis ServiceWorker registered successfully:', reg.scope);
      })
      .catch((err) => {
        console.warn('Solis ServiceWorker registration error:', err);
      });
  });
}
