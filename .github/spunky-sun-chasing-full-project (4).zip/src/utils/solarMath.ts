/**
 * High-accuracy astronomical solar position and phase calculation
 * based on NOAA Solar Calculator algorithms and Jean Meeus' Astronomical Algorithms.
 * 100% offline, pure mathematics, zero network requests.
 */

export interface SolarTimes {
  astronomicalDawn: Date | null;
  nauticalDawn: Date | null;
  civilDawn: Date | null;
  blueHourDawnStart: Date | null;
  blueHourDawnEnd: Date | null;
  goldenHourDawnStart: Date | null;
  goldenHourDawnEnd: Date | null;
  sunrise: Date | null;
  solarNoon: Date | null;
  sunset: Date | null;
  goldenHourDuskStart: Date | null;
  goldenHourDuskEnd: Date | null;
  blueHourDuskStart: Date | null;
  blueHourDuskEnd: Date | null;
  civilDusk: Date | null;
  nauticalDusk: Date | null;
  astronomicalDusk: Date | null;
  nadir: Date | null;
  dayLengthMinutes: number;
  maxSolarElevation: number; // in degrees
}

export interface SolarPosition {
  elevation: number; // in degrees (-90 to +90)
  azimuth: number; // in degrees (0 to 360, 0=North, 90=East, 180=South, 270=West)
  distanceAU: number; // distance to sun in Astronomical Units
}

export type SolarPhase =
  | 'night'
  | 'astronomical_twilight'
  | 'nautical_twilight'
  | 'blue_hour_dawn'
  | 'golden_hour_dawn'
  | 'day'
  | 'golden_hour_dusk'
  | 'blue_hour_dusk';

export interface SolarPhaseInfo {
  phase: SolarPhase;
  name: string;
  description: string;
  colorHex: string;
  isGoldenHour: boolean;
  isBlueHour: boolean;
  isDaytime: boolean;
}

const RAD = Math.PI / 180;
const DEG = 180 / Math.PI;

/** Convert Date to Julian Date */
function toJulianDate(date: Date): number {
  return date.getTime() / 86400000 + 2440587.5;
}

/** Convert Julian Date to Date */
function fromJulianDate(jd: number): Date {
  return new Date((jd - 2440587.5) * 86400000);
}

/** Julian century from Julian Date */
function toJulianCentury(jd: number): number {
  return (jd - 2451545.0) / 36525.0;
}

/** Geometric Mean Longitude of Sun in degrees */
function geomMeanLongSun(t: number): number {
  let l0 = 280.46646 + t * (36000.76983 + 0.0003032 * t);
  while (l0 > 360.0) l0 -= 360.0;
  while (l0 < 0.0) l0 += 360.0;
  return l0;
}

/** Geometric Mean Anomaly of Sun in degrees */
function geomMeanAnomalySun(t: number): number {
  return 357.52911 + t * (35999.05029 - 0.0001537 * t);
}

/** Eccentricity of Earth's orbit */
function eccEarthOrbit(t: number): number {
  return 0.016708634 - t * (0.000042037 + 0.0000001267 * t);
}

/** Sun Equation of the Center in degrees */
function sunEqOfCenter(t: number): number {
  const m = geomMeanAnomalySun(t) * RAD;
  return (
    Math.sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t)) +
    Math.sin(2 * m) * (0.019993 - 0.000101 * t) +
    Math.sin(3 * m) * 0.000289
  );
}

/** Sun True Longitude in degrees */
function sunTrueLong(t: number): number {
  return geomMeanLongSun(t) + sunEqOfCenter(t);
}

/** Sun Apparent Longitude in degrees */
function sunApparentLong(t: number): number {
  const o = sunTrueLong(t);
  const omega = 125.04 - 1934.136 * t;
  return o - 0.00569 - 0.00478 * Math.sin(omega * RAD);
}

/** Mean Obliquity of the Ecliptic in degrees */
function meanObliquityOfEcliptic(t: number): number {
  const seconds = 21.448 - t * (46.8150 + t * (0.00059 - t * 0.001813));
  return 23.0 + (26.0 + seconds / 60.0) / 60.0;
}

/** Obliquity Correction in degrees */
function obliquityCorrection(t: number): number {
  const e0 = meanObliquityOfEcliptic(t);
  const omega = 125.04 - 1934.136 * t;
  return e0 + 0.00256 * Math.cos(omega * RAD);
}

/** Sun Declination in degrees */
function sunDeclination(t: number): number {
  const e = obliquityCorrection(t) * RAD;
  const lambda = sunApparentLong(t) * RAD;
  return Math.asin(Math.sin(e) * Math.sin(lambda)) * DEG;
}

/** Equation of Time in minutes */
function equationOfTime(t: number): number {
  const epsilon = obliquityCorrection(t) * RAD;
  const l0 = geomMeanLongSun(t) * RAD;
  const e = eccEarthOrbit(t);
  const m = geomMeanAnomalySun(t) * RAD;

  let y = Math.tan(epsilon / 2.0);
  y *= y;

  const sin2l0 = Math.sin(2.0 * l0);
  const sinm = Math.sin(m);
  const cos2l0 = Math.cos(2.0 * l0);
  const sin4l0 = Math.sin(4.0 * l0);
  const sin2m = Math.sin(2.0 * m);

  const eTime =
    y * sin2l0 -
    2.0 * e * sinm +
    4.0 * e * y * sinm * cos2l0 -
    0.5 * y * y * sin4l0 -
    1.25 * e * e * sin2m;

  return eTime * 4.0 * DEG;
}

/** Hour angle in degrees for given solar zenith angle */
function hourAngle(lat: number, decl: number, zenith: number): number | null {
  const latRad = lat * RAD;
  const declRad = decl * RAD;
  const zenithRad = zenith * RAD;

  const cosH =
    (Math.cos(zenithRad) - Math.sin(latRad) * Math.sin(declRad)) /
    (Math.cos(latRad) * Math.cos(declRad));

  if (cosH > 1.0) {
    // Sun never reaches this zenith (polar night)
    return null;
  }
  if (cosH < -1.0) {
    // Sun is always higher than this zenith (midnight sun)
    return null;
  }

  return Math.acos(cosH) * DEG;
}

/** Calculate time of transit / rising / setting */
function calcSolarEventTime(
  date: Date,
  lat: number,
  lng: number,
  zenithAngle: number,
  isRise: boolean
): Date | null {
  // Midnight UTC of target date
  const baseMidnight = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const jd = toJulianDate(baseMidnight);
  const t = toJulianCentury(jd);
  const eqTime = equationOfTime(t);
  const decl = sunDeclination(t);

  const ha = hourAngle(lat, decl, zenithAngle);
  if (ha === null) return null;

  const deltaHa = isRise ? -ha : ha;
  // Solar noon in UTC minutes from midnight
  const timeDiff = deltaHa * 4.0;
  const noonMinutes = 720 - lng * 4.0 - eqTime;
  const eventMinutes = noonMinutes + timeDiff;

  const result = new Date(baseMidnight.getTime() + eventMinutes * 60000);
  return result;
}

/**
 * Calculates current solar position (elevation angle and azimuth)
 */
export function calculateSolarPosition(date: Date, lat: number, lng: number): SolarPosition {
  const jd = toJulianDate(date);
  const t = toJulianCentury(jd);

  const l0 = geomMeanLongSun(t);
  const m = geomMeanAnomalySun(t) * RAD;
  const c = sunEqOfCenter(t);
  const trueLong = l0 + c;
  const apparentLong = sunApparentLong(t) * RAD;
  const obliq = obliquityCorrection(t) * RAD;

  const decl = Math.asin(Math.sin(obliq) * Math.sin(apparentLong));
  const rightAscension = Math.atan2(
    Math.cos(obliq) * Math.sin(apparentLong),
    Math.cos(apparentLong)
  );

  // Greenwich Mean Sidereal Time
  const d0 = jd - 2451545.0;
  const gmst = 280.46061837 + 360.98564736629 * d0;
  const lmst = (gmst + lng) * RAD;

  const hourAngleVal = lmst - rightAscension;
  const latRad = lat * RAD;

  const sinElevation =
    Math.sin(latRad) * Math.sin(decl) +
    Math.cos(latRad) * Math.cos(decl) * Math.cos(hourAngleVal);
  const elevation = Math.asin(sinElevation) * DEG;

  const cosAzimuth =
    (Math.sin(decl) - Math.sin(latRad) * sinElevation) /
    (Math.cos(latRad) * Math.cos(elevation * RAD));
  let azimuth = Math.acos(Math.max(-1, Math.min(1, cosAzimuth))) * DEG;

  if (Math.sin(hourAngleVal) > 0) {
    azimuth = 360 - azimuth;
  }

  // Distance in AU
  const e = eccEarthOrbit(t);
  const distanceAU = (1.000001018 * (1 - e * e)) / (1 + e * Math.cos(m));

  return {
    elevation: Math.round(elevation * 100) / 100,
    azimuth: Math.round(azimuth * 100) / 100,
    distanceAU: Math.round(distanceAU * 1000) / 1000,
  };
}

/**
 * Calculates all solar events and phases for a specific date and coordinates
 */
export function calculateSolarTimes(date: Date, lat: number, lng: number): SolarTimes {
  // Atmospheric refraction + solar semi-diameter standard = 90.833°
  const OFFICIAL_ZENITH = 90.833;
  // Civil Twilight = -6° elevation -> 96° zenith
  const CIVIL_ZENITH = 96.0;
  // Nautical Twilight = -12° elevation -> 102° zenith
  const NAUTICAL_ZENITH = 102.0;
  // Astronomical Twilight = -18° elevation -> 108° zenith
  const ASTRONOMICAL_ZENITH = 108.0;
  // Golden Hour = sun between -4° (94° zenith) and +6° (84° zenith)
  const GOLDEN_HOUR_LOWER = 94.0;
  const GOLDEN_HOUR_UPPER = 84.0;
  // Blue Hour = sun between -6° (96° zenith) and -4° (94° zenith)
  const BLUE_HOUR_LOWER = 96.0;
  const BLUE_HOUR_UPPER = 94.0;

  const sunrise = calcSolarEventTime(date, lat, lng, OFFICIAL_ZENITH, true);
  const sunset = calcSolarEventTime(date, lat, lng, OFFICIAL_ZENITH, false);

  const civilDawn = calcSolarEventTime(date, lat, lng, CIVIL_ZENITH, true);
  const civilDusk = calcSolarEventTime(date, lat, lng, CIVIL_ZENITH, false);

  const nauticalDawn = calcSolarEventTime(date, lat, lng, NAUTICAL_ZENITH, true);
  const nauticalDusk = calcSolarEventTime(date, lat, lng, NAUTICAL_ZENITH, false);

  const astronomicalDawn = calcSolarEventTime(date, lat, lng, ASTRONOMICAL_ZENITH, true);
  const astronomicalDusk = calcSolarEventTime(date, lat, lng, ASTRONOMICAL_ZENITH, false);

  // Morning Golden Hour: from -4° to +6°
  const goldenHourDawnStart = calcSolarEventTime(date, lat, lng, GOLDEN_HOUR_LOWER, true);
  const goldenHourDawnEnd = calcSolarEventTime(date, lat, lng, GOLDEN_HOUR_UPPER, true);

  // Evening Golden Hour: from +6° to -4°
  const goldenHourDuskStart = calcSolarEventTime(date, lat, lng, GOLDEN_HOUR_UPPER, false);
  const goldenHourDuskEnd = calcSolarEventTime(date, lat, lng, GOLDEN_HOUR_LOWER, false);

  // Morning Blue Hour: from -6° to -4°
  const blueHourDawnStart = calcSolarEventTime(date, lat, lng, BLUE_HOUR_LOWER, true);
  const blueHourDawnEnd = calcSolarEventTime(date, lat, lng, BLUE_HOUR_UPPER, true);

  // Evening Blue Hour: from -4° to -6°
  const blueHourDuskStart = calcSolarEventTime(date, lat, lng, BLUE_HOUR_UPPER, false);
  const blueHourDuskEnd = calcSolarEventTime(date, lat, lng, BLUE_HOUR_LOWER, false);

  // Solar Noon (zenith passage)
  const baseMidnight = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const jd = toJulianDate(baseMidnight);
  const t = toJulianCentury(jd);
  const eqTime = equationOfTime(t);
  const noonMinutes = 720 - lng * 4.0 - eqTime;
  const solarNoon = new Date(baseMidnight.getTime() + noonMinutes * 60000);
  const nadir = new Date(solarNoon.getTime() + 12 * 3600000);

  // Day length
  let dayLengthMinutes = 0;
  if (sunrise && sunset) {
    dayLengthMinutes = Math.max(0, Math.round((sunset.getTime() - sunrise.getTime()) / 60000));
  } else if (!sunrise && !sunset) {
    // Check if polar day or polar night
    const noonPos = calculateSolarPosition(solarNoon, lat, lng);
    dayLengthMinutes = noonPos.elevation > 0 ? 1440 : 0;
  }

  // Max elevation at solar noon
  const maxSolarElevation = calculateSolarPosition(solarNoon, lat, lng).elevation;

  return {
    astronomicalDawn,
    nauticalDawn,
    civilDawn,
    blueHourDawnStart,
    blueHourDawnEnd,
    goldenHourDawnStart,
    goldenHourDawnEnd,
    sunrise,
    solarNoon,
    sunset,
    goldenHourDuskStart,
    goldenHourDuskEnd,
    blueHourDuskStart,
    blueHourDuskEnd,
    civilDusk,
    nauticalDusk,
    astronomicalDusk,
    nadir,
    dayLengthMinutes,
    maxSolarElevation,
  };
}

/**
 * Returns current solar phase description and metadata based on elevation and time of day
 */
export function getSolarPhaseInfo(elevation: number, isMorning: boolean): SolarPhaseInfo {
  if (elevation < -18) {
    return {
      phase: 'night',
      name: 'Deep Night',
      description: 'The sky is completely dark. Ideal for stargazing and deep astrophotography.',
      colorHex: '#0f141c',
      isGoldenHour: false,
      isBlueHour: false,
      isDaytime: false,
    };
  } else if (elevation < -12) {
    return {
      phase: 'astronomical_twilight',
      name: 'Astronomical Twilight',
      description: 'The sun is between 12° and 18° below the horizon. The faintest stars are visible.',
      colorHex: '#161c28',
      isGoldenHour: false,
      isBlueHour: false,
      isDaytime: false,
    };
  } else if (elevation < -6) {
    return {
      phase: 'nautical_twilight',
      name: 'Nautical Twilight',
      description: 'The horizon becomes faintly visible against the sky; sea navigators take stellar fixes.',
      colorHex: '#1d273a',
      isGoldenHour: false,
      isBlueHour: false,
      isDaytime: false,
    };
  } else if (elevation < -4) {
    return {
      phase: isMorning ? 'blue_hour_dawn' : 'blue_hour_dusk',
      name: isMorning ? 'Morning Blue Hour' : 'Evening Blue Hour',
      description: 'Deep cobalt sky with soft atmospheric scattered light. Highly prized for cityscapes.',
      colorHex: '#253556',
      isGoldenHour: false,
      isBlueHour: true,
      isDaytime: false,
    };
  } else if (elevation < 6) {
    return {
      phase: isMorning ? 'golden_hour_dawn' : 'golden_hour_dusk',
      name: isMorning ? 'Morning Golden Hour' : 'Evening Golden Hour',
      description: 'Warm, low-angle golden light with long dramatic shadows and soft warm color temperature.',
      colorHex: '#e08b34',
      isGoldenHour: true,
      isBlueHour: false,
      isDaytime: elevation >= 0,
    };
  } else {
    return {
      phase: 'day',
      name: 'Daylight',
      description: 'Direct sunlight illuminate the landscape with high contrast and natural daylight tones.',
      colorHex: '#3a86ff',
      isGoldenHour: false,
      isBlueHour: false,
      isDaytime: true,
    };
  }
}

/** Formats a Date object to local time HH:MM or HH:MM:SS */
export function formatSolarTime(date: Date | null, includeSeconds = false): string {
  if (!date) return '--:--';
  return date.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: includeSeconds ? '2-digit' : undefined,
    hour12: false,
  });
}

/** Formats minutes into hours and minutes string (e.g. "12h 45m") */
export function formatDuration(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}
