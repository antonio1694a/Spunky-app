/**
 * Offline storage and location database for Solis
 * Provides offline caching via localStorage and built-in global coordinate directory.
 */

import { NotificationSettings, DEFAULT_NOTIFICATION_SETTINGS } from './notifications';
import { ThemePreference } from './themeEngine';

export interface LocationData {
  id: string;
  name: string;
  region?: string;
  country: string;
  latitude: number;
  longitude: number;
  isFavorite?: boolean;
  isCustom?: boolean;
}

/** Pre-indexed worldwide scenic & major locations for 100% offline lookup */
export const OFFLINE_LOCATIONS: LocationData[] = [
  { id: 'sf', name: 'San Francisco', region: 'California', country: 'United States', latitude: 37.7749, longitude: -122.4194 },
  { id: 'nyc', name: 'New York City', region: 'New York', country: 'United States', latitude: 40.7128, longitude: -74.006 },
  { id: 'london', name: 'London', region: 'England', country: 'United Kingdom', latitude: 51.5074, longitude: -0.1278 },
  { id: 'paris', name: 'Paris', region: 'Île-de-France', country: 'France', latitude: 48.8566, longitude: 2.3522 },
  { id: 'tokyo', name: 'Tokyo', region: 'Kanto', country: 'Japan', latitude: 35.6762, longitude: 139.6503 },
  { id: 'sydney', name: 'Sydney', region: 'New South Wales', country: 'Australia', latitude: -33.8688, longitude: 151.2093 },
  { id: 'reykjavik', name: 'Reykjavík', region: 'Capital Region', country: 'Iceland', latitude: 64.1466, longitude: -21.9426 },
  { id: 'cairo', name: 'Cairo', region: 'Cairo Governorate', country: 'Egypt', latitude: 30.0444, longitude: 31.2357 },
  { id: 'rio', name: 'Rio de Janeiro', region: 'Rio de Janeiro', country: 'Brazil', latitude: -22.9068, longitude: -43.1729 },
  { id: 'capetown', name: 'Cape Town', region: 'Western Cape', country: 'South Africa', latitude: -33.9249, longitude: 18.4241 },
  { id: 'dubai', name: 'Dubai', region: 'Dubai Emirate', country: 'United Arab Emirates', latitude: 25.2048, longitude: 55.2708 },
  { id: 'rome', name: 'Rome', region: 'Lazio', country: 'Italy', latitude: 41.9028, longitude: 12.4964 },
  { id: 'honolulu', name: 'Honolulu', region: 'Hawaii', country: 'United States', latitude: 21.3069, longitude: -157.8583 },
  { id: 'banff', name: 'Banff National Park', region: 'Alberta', country: 'Canada', latitude: 51.1784, longitude: -115.5708 },
  { id: 'santorini', name: 'Santorini', region: 'South Aegean', country: 'Greece', latitude: 36.3932, longitude: 25.4615 },
  { id: 'zermatt', name: 'Zermatt (Matterhorn)', region: 'Valais', country: 'Switzerland', latitude: 45.9763, longitude: 7.7491 },
  { id: 'tromso', name: 'Tromsø (Northern Lights)', region: 'Troms', country: 'Norway', latitude: 69.6492, longitude: 18.9553 },
  { id: 'kyoto', name: 'Kyoto', region: 'Kansai', country: 'Japan', latitude: 35.0116, longitude: 135.7681 },
  { id: 'maui', name: 'Haleakalā (Maui)', region: 'Hawaii', country: 'United States', latitude: 20.7097, longitude: -156.2534 },
  { id: 'grandcanyon', name: 'Grand Canyon South Rim', region: 'Arizona', country: 'United States', latitude: 36.0544, longitude: -112.1401 },
  { id: 'singapore', name: 'Singapore', region: 'Central Area', country: 'Singapore', latitude: 1.3521, longitude: 103.8198 },
  { id: 'auckland', name: 'Auckland', region: 'North Island', country: 'New Zealand', latitude: -36.8485, longitude: 174.7633 },
  { id: 'berlin', name: 'Berlin', region: 'Berlin', country: 'Germany', latitude: 52.52, longitude: 13.405 },
  { id: 'buenosaires', name: 'Buenos Aires', region: 'Capital District', country: 'Argentina', latitude: -34.6037, longitude: -58.3816 },
  { id: 'seattle', name: 'Seattle', region: 'Washington', country: 'United States', latitude: 47.6062, longitude: -122.3321 },
];

const STORAGE_KEYS = {
  ACTIVE_LOCATION: 'solis_active_location',
  FAVORITES: 'solis_favorites',
  NOTIFICATIONS: 'solis_notifications',
  THEME_PREFERENCE: 'solis_theme_preference',
};

/** Default fallback location (San Francisco) */
export const DEFAULT_LOCATION: LocationData = OFFLINE_LOCATIONS[0];

/** Load active location from localStorage */
export function getActiveLocation(): LocationData {
  if (typeof window === 'undefined') return DEFAULT_LOCATION;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_LOCATION);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Error reading active location:', err);
  }
  return DEFAULT_LOCATION;
}

/** Save active location to localStorage */
export function saveActiveLocation(loc: LocationData): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_LOCATION, JSON.stringify(loc));
  } catch (err) {
    console.warn('Error saving active location:', err);
  }
}

/** Load favorite locations */
export function getFavoriteLocations(): LocationData[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (err) {
    console.warn('Error reading favorites:', err);
  }
  return [];
}

/** Save favorite locations */
export function saveFavoriteLocations(list: LocationData[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(list));
  } catch (err) {
    console.warn('Error saving favorites:', err);
  }
}

/** Load notification settings */
export function getStoredNotificationSettings(): NotificationSettings {
  if (typeof window === 'undefined') return DEFAULT_NOTIFICATION_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (raw) {
      return { ...DEFAULT_NOTIFICATION_SETTINGS, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.warn('Error reading notification settings:', err);
  }
  return DEFAULT_NOTIFICATION_SETTINGS;
}

/** Save notification settings */
export function saveNotificationSettings(settings: NotificationSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(settings));
  } catch (err) {
    console.warn('Error saving notification settings:', err);
  }
}

/** Load theme preference */
export function getStoredThemePreference(): ThemePreference {
  if (typeof window === 'undefined') return 'auto';
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.THEME_PREFERENCE);
    if (raw === 'dark' || raw === 'light' || raw === 'auto') {
      return raw;
    }
  } catch (err) {
    console.warn('Error reading theme preference:', err);
  }
  return 'auto';
}

/** Save theme preference */
export function saveThemePreference(pref: ThemePreference): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.THEME_PREFERENCE, pref);
  } catch (err) {
    console.warn('Error saving theme preference:', err);
  }
}
