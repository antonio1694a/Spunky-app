/**
 * Notification & Alert Engine for Solis
 * Handles Web Notifications API, Web Audio API sound synthesis chime,
 * and time-based alert triggers for Golden Hour & Blue Hour.
 */

export type AlertLeadTime = 0 | 15 | 30; // minutes before event

export interface NotificationSettings {
  enabled: boolean;
  goldenHourMorning: boolean;
  goldenHourEvening: boolean;
  blueHourMorning: boolean;
  blueHourEvening: boolean;
  leadTimeMinutes: AlertLeadTime;
  soundEnabled: boolean;
}

export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  enabled: false,
  goldenHourMorning: true,
  goldenHourEvening: true,
  blueHourMorning: false,
  blueHourEvening: false,
  leadTimeMinutes: 0, // Exactly when Golden Hour starts (as confirmed by user)
  soundEnabled: true,
};

/**
 * Checks if browser supports Notifications
 */
export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

/**
 * Gets current notification permission status ('granted' | 'denied' | 'default')
 */
export function getNotificationPermission(): NotificationPermission {
  if (!isNotificationSupported()) return 'denied';
  return Notification.permission;
}

/**
 * Requests notification permission from user
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNotificationSupported()) return false;
  try {
    const result = await Notification.requestPermission();
    return result === 'granted';
  } catch (err) {
    console.error('Error requesting notification permission:', err);
    return false;
  }
}

/**
 * Plays a warm golden chime using Web Audio API synthesis
 * (two-stage harmonic bell chords: 523.25Hz C5 -> 659.25Hz E5 -> 783.99Hz G5)
 */
export function playGoldenHourChime(): void {
  if (typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 chord
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.08);

      gain.gain.setValueAtTime(0, now + idx * 0.08);
      gain.gain.linearRampToValueAtTime(0.18, now + idx * 0.08 + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + idx * 0.08);
      osc.stop(now + idx * 0.08 + 1.3);
    });
  } catch (err) {
    console.warn('Audio chime playback error:', err);
  }
}

export type NotificationListener = (title: string, body: string) => void;
let listeners: NotificationListener[] = [];

export function subscribeNotification(listener: NotificationListener): () => void {
  listeners.push(listener);
  return () => {
    listeners = listeners.filter((l) => l !== listener);
  };
}

/**
 * Triggers a system notification, in-app visual alert, and optional audio chime
 */
export function triggerNotification(title: string, body: string, playSound = true): void {
  if (playSound) {
    playGoldenHourChime();
  }

  // Trigger in-app visual toast message subscribers immediately
  listeners.forEach((listener) => {
    try {
      listener(title, body);
    } catch (e) {
      console.warn('Notification listener error:', e);
    }
  });

  // Trigger vibration if supported on mobile
  if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
    try {
      navigator.vibrate([200, 100, 200]);
    } catch {
      // ignore
    }
  }

  if (isNotificationSupported() && Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/icon.svg',
        badge: '/icon.svg',
        tag: 'solis-golden-hour',
      });
    } catch {
      // On some mobile devices, must use ServiceWorkerRegistration.showNotification
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then((reg) => {
          reg.showNotification(title, {
            body,
            icon: '/icon.svg',
            badge: '/icon.svg',
            tag: 'solis-golden-hour',
          });
        });
      }
    }
  }
}
