/**
 * Material You 3 (Material Design 3) Dynamic Solar Theme Engine
 * Calculates dynamic tonal color palettes and atmospheric sky gradients
 * based on solar elevation, time-of-day phase, and user preference.
 */

import { SolarPhase } from './solarMath';

export type ThemePreference = 'auto' | 'dark' | 'light';

export interface DynamicTheme {
  isDark: boolean;
  backgroundGradient: string;
  skyOverlayGradient: string;
  surface: string;
  surfaceContainer: string;
  surfaceContainerHigh: string;
  primary: string;
  onPrimary: string;
  primaryContainer: string;
  onPrimaryContainer: string;
  secondary: string;
  tertiary: string;
  outline: string;
  textPrimary: string;
  textSecondary: string;
  sunGlowColor: string;
  cardBorder: string;
  pillActiveBg: string;
}

/**
 * Returns dynamic Material 3 tonal theme tokens based on elevation and mode
 */
export function getDynamicTheme(
  elevation: number,
  phase: SolarPhase,
  preference: ThemePreference = 'auto'
): DynamicTheme {
  // Determine if UI should be in dark or light posture
  let isDark = true;
  if (preference === 'dark') {
    isDark = true;
  } else if (preference === 'light') {
    isDark = false;
  } else {
    // Auto mode: dark when sun is below horizon or during deep twilight
    isDark = elevation < 2;
  }

  // Atmospheric sky gradients based on sun elevation angle
  if (elevation < -18) {
    // Deep Night
    return {
      isDark: true,
      backgroundGradient: 'linear-gradient(180deg, #07090e 0%, #0d121c 50%, #111827 100%)',
      skyOverlayGradient: 'radial-gradient(ellipse at 50% 80%, rgba(30, 41, 59, 0.4) 0%, transparent 70%)',
      surface: 'rgba(15, 23, 42, 0.75)',
      surfaceContainer: 'rgba(30, 41, 59, 0.65)',
      surfaceContainerHigh: 'rgba(51, 65, 85, 0.65)',
      primary: '#93c5fd', // Soft celestial blue
      onPrimary: '#0f172a',
      primaryContainer: 'rgba(30, 58, 138, 0.5)',
      onPrimaryContainer: '#dbeafe',
      secondary: '#c7d2fe',
      tertiary: '#fbcfe8',
      outline: 'rgba(148, 163, 184, 0.15)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      sunGlowColor: 'rgba(147, 197, 253, 0.25)',
      cardBorder: 'rgba(255, 255, 255, 0.08)',
      pillActiveBg: '#3b82f6',
    };
  } else if (elevation < -12) {
    // Astronomical Twilight
    return {
      isDark: true,
      backgroundGradient: 'linear-gradient(180deg, #090e17 0%, #131c2e 50%, #1e263d 100%)',
      skyOverlayGradient: 'radial-gradient(ellipse at 50% 85%, rgba(67, 56, 202, 0.25) 0%, transparent 65%)',
      surface: 'rgba(19, 28, 46, 0.8)',
      surfaceContainer: 'rgba(30, 41, 69, 0.7)',
      surfaceContainerHigh: 'rgba(49, 64, 102, 0.7)',
      primary: '#a5b4fc',
      onPrimary: '#1e1b4b',
      primaryContainer: 'rgba(49, 46, 129, 0.6)',
      onPrimaryContainer: '#e0e7ff',
      secondary: '#c4b5fd',
      tertiary: '#f472b6',
      outline: 'rgba(165, 180, 252, 0.18)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      sunGlowColor: 'rgba(165, 180, 252, 0.35)',
      cardBorder: 'rgba(165, 180, 252, 0.12)',
      pillActiveBg: '#6366f1',
    };
  } else if (elevation < -6) {
    // Nautical Twilight
    return {
      isDark: true,
      backgroundGradient: 'linear-gradient(180deg, #0d1527 0%, #1b2845 45%, #312b4f 100%)',
      skyOverlayGradient: 'radial-gradient(ellipse at 50% 90%, rgba(139, 92, 246, 0.3) 0%, transparent 65%)',
      surface: 'rgba(23, 33, 56, 0.82)',
      surfaceContainer: 'rgba(36, 49, 82, 0.72)',
      surfaceContainerHigh: 'rgba(56, 73, 117, 0.72)',
      primary: '#c084fc',
      onPrimary: '#2e1065',
      primaryContainer: 'rgba(88, 28, 135, 0.55)',
      onPrimaryContainer: '#f3e8ff',
      secondary: '#818cf8',
      tertiary: '#f43f5e',
      outline: 'rgba(192, 132, 252, 0.2)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      sunGlowColor: 'rgba(192, 132, 252, 0.45)',
      cardBorder: 'rgba(192, 132, 252, 0.15)',
      pillActiveBg: '#8b5cf6',
    };
  } else if (elevation < -4) {
    // Blue Hour
    return {
      isDark: true,
      backgroundGradient: 'linear-gradient(180deg, #101c38 0%, #1e3563 50%, #4a3e63 100%)',
      skyOverlayGradient: 'radial-gradient(ellipse at 50% 92%, rgba(236, 72, 153, 0.28) 0%, transparent 70%)',
      surface: 'rgba(26, 40, 71, 0.84)',
      surfaceContainer: 'rgba(38, 58, 99, 0.74)',
      surfaceContainerHigh: 'rgba(56, 82, 138, 0.74)',
      primary: '#60a5fa',
      onPrimary: '#082f49',
      primaryContainer: 'rgba(14, 116, 144, 0.6)',
      onPrimaryContainer: '#e0f2fe',
      secondary: '#f472b6',
      tertiary: '#fb923c',
      outline: 'rgba(96, 165, 250, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#cbd5e1',
      sunGlowColor: 'rgba(244, 114, 182, 0.55)',
      cardBorder: 'rgba(96, 165, 250, 0.18)',
      pillActiveBg: '#2563eb',
    };
  } else if (elevation < 6) {
    // Golden Hour (Sunrise / Sunset)
    if (isDark) {
      return {
        isDark: true,
        backgroundGradient: 'linear-gradient(180deg, #1b2238 0%, #4a2835 40%, #873e23 75%, #c25e1a 100%)',
        skyOverlayGradient: 'radial-gradient(ellipse at 50% 95%, rgba(251, 146, 60, 0.45) 0%, transparent 60%)',
        surface: 'rgba(35, 24, 32, 0.86)',
        surfaceContainer: 'rgba(56, 36, 44, 0.76)',
        surfaceContainerHigh: 'rgba(82, 49, 58, 0.76)',
        primary: '#fbbf24', // Rich gold
        onPrimary: '#451a03',
        primaryContainer: 'rgba(120, 53, 15, 0.6)',
        onPrimaryContainer: '#fef3c7',
        secondary: '#f97316',
        tertiary: '#f43f5e',
        outline: 'rgba(251, 191, 36, 0.25)',
        textPrimary: '#fffbeb',
        textSecondary: '#fed7aa',
        sunGlowColor: 'rgba(251, 191, 36, 0.75)',
        cardBorder: 'rgba(251, 191, 36, 0.22)',
        pillActiveBg: '#d97706',
      };
    } else {
      return {
        isDark: false,
        backgroundGradient: 'linear-gradient(180deg, #dbeafe 0%, #fed7aa 50%, #fdba74 85%, #f97316 100%)',
        skyOverlayGradient: 'radial-gradient(ellipse at 50% 95%, rgba(255, 237, 213, 0.7) 0%, transparent 60%)',
        surface: 'rgba(255, 255, 255, 0.92)',
        surfaceContainer: 'rgba(254, 243, 199, 0.85)',
        surfaceContainerHigh: 'rgba(253, 230, 138, 0.85)',
        primary: '#b45309',
        onPrimary: '#ffffff',
        primaryContainer: '#fef3c7',
        onPrimaryContainer: '#78350f',
        secondary: '#c2410c',
        tertiary: '#be123c',
        outline: 'rgba(180, 83, 9, 0.25)',
        textPrimary: '#451a03',
        textSecondary: '#78350f',
        sunGlowColor: 'rgba(245, 158, 11, 0.85)',
        cardBorder: 'rgba(217, 119, 6, 0.22)',
        pillActiveBg: '#d97706',
      };
    }
  } else {
    // Full Daylight
    if (isDark) {
      return {
        isDark: true,
        backgroundGradient: 'linear-gradient(180deg, #132238 0%, #1e3a5f 45%, #244b7a 100%)',
        skyOverlayGradient: 'radial-gradient(ellipse at 50% 20%, rgba(56, 189, 248, 0.25) 0%, transparent 65%)',
        surface: 'rgba(19, 34, 56, 0.85)',
        surfaceContainer: 'rgba(29, 52, 85, 0.75)',
        surfaceContainerHigh: 'rgba(42, 72, 115, 0.75)',
        primary: '#38bdf8', // Daylight sky blue
        onPrimary: '#082f49',
        primaryContainer: 'rgba(3, 105, 161, 0.6)',
        onPrimaryContainer: '#e0f2fe',
        secondary: '#facc15',
        tertiary: '#34d399',
        outline: 'rgba(56, 189, 248, 0.2)',
        textPrimary: '#f0f9ff',
        textSecondary: '#94a3b8',
        sunGlowColor: 'rgba(250, 204, 21, 0.75)',
        cardBorder: 'rgba(56, 189, 248, 0.16)',
        pillActiveBg: '#0284c7',
      };
    } else {
      return {
        isDark: false,
        backgroundGradient: 'linear-gradient(180deg, #38bdf8 0%, #7dd3fc 45%, #e0f2fe 100%)',
        skyOverlayGradient: 'radial-gradient(ellipse at 50% 15%, rgba(255, 255, 255, 0.5) 0%, transparent 60%)',
        surface: 'rgba(255, 255, 255, 0.94)',
        surfaceContainer: 'rgba(240, 249, 255, 0.88)',
        surfaceContainerHigh: 'rgba(224, 242, 254, 0.88)',
        primary: '#0284c7',
        onPrimary: '#ffffff',
        primaryContainer: '#e0f2fe',
        onPrimaryContainer: '#0369a1',
        secondary: '#d97706',
        tertiary: '#059669',
        outline: 'rgba(2, 132, 199, 0.2)',
        textPrimary: '#082f49',
        textSecondary: '#334155',
        sunGlowColor: 'rgba(234, 179, 8, 0.8)',
        cardBorder: 'rgba(2, 132, 199, 0.18)',
        pillActiveBg: '#0284c7',
      };
    }
  }
}
