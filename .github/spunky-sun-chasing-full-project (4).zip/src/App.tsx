/**
 * Solis — Sunrise, Sunset & Golden Hour Navigator
 * Material You 3 Dynamic Solar Architecture
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  calculateSolarPosition,
  calculateSolarTimes,
  getSolarPhaseInfo,
  SolarPhase,
  formatSolarTime,
} from './utils/solarMath';
import { getDynamicTheme, ThemePreference } from './utils/themeEngine';
import {
  LocationData,
  getActiveLocation,
  saveActiveLocation,
  getFavoriteLocations,
  saveFavoriteLocations,
  getStoredNotificationSettings,
  saveNotificationSettings,
  getStoredThemePreference,
  saveThemePreference,
} from './utils/storage';
import {
  NotificationSettings,
  triggerNotification,
} from './utils/notifications';
import { Header } from './components/Header';
import { SolarArc } from './components/SolarArc';
import { GoldenHourBanner } from './components/GoldenHourBanner';
import { TimeScrubber } from './components/TimeScrubber';
import { PhaseCardList } from './components/PhaseCardList';
import { LocationModal } from './components/LocationModal';
import { NotificationModal } from './components/NotificationModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { OneUIWidget } from './components/OneUIWidget';
import { NotificationToast } from './components/NotificationToast';
import { Moon, Globe, Info } from 'lucide-react';

export default function App() {
  // Location & favorites
  const [activeLocation, setActiveLocation] = useState<LocationData>(getActiveLocation);
  const [favorites, setFavorites] = useState<LocationData[]>(getFavoriteLocations);

  // Time & Simulation state
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [isLive, setIsLive] = useState<boolean>(true);

  // Theme & Notifications
  const [themePreference, setThemePreference] = useState<ThemePreference>(getStoredThemePreference);
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(
    getStoredNotificationSettings
  );

  // Modals & Views
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [isNotificationModalOpen, setIsNotificationModalOpen] = useState(false);
  const [showWidgetStudio, setShowWidgetStudio] = useState(false);

  // Last triggered alert tracker to avoid duplicate notification triggers
  const lastFiredPhaseRef = useRef<string | null>(null);

  // Real-time tick effect (runs every 1 second when in Live mode)
  useEffect(() => {
    if (!isLive) return;
    const interval = window.setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, [isLive]);

  // Solar Calculations (NOAA mathematical algorithm)
  const solarTimes = useMemo(() => {
    return calculateSolarTimes(
      currentTime,
      activeLocation.latitude,
      activeLocation.longitude
    );
  }, [currentTime, activeLocation]);

  const solarPosition = useMemo(() => {
    return calculateSolarPosition(
      currentTime,
      activeLocation.latitude,
      activeLocation.longitude
    );
  }, [currentTime, activeLocation]);

  // Determine if it is morning or afternoon for twilight determination
  const isMorning = useMemo(() => {
    if (solarTimes.solarNoon) {
      return currentTime.getTime() < solarTimes.solarNoon.getTime();
    }
    return currentTime.getHours() < 12;
  }, [currentTime, solarTimes]);

  const currentPhaseInfo = useMemo(() => {
    return getSolarPhaseInfo(solarPosition.elevation, isMorning);
  }, [solarPosition.elevation, isMorning]);

  // Dynamic Material You 3 Theme computed from solar elevation & user mode
  const dynamicTheme = useMemo(() => {
    return getDynamicTheme(
      solarPosition.elevation,
      currentPhaseInfo.phase,
      themePreference
    );
  }, [solarPosition.elevation, currentPhaseInfo.phase, themePreference]);

  // Automatic Golden Hour Alert Monitor
  useEffect(() => {
    if (!notificationSettings.enabled || !isLive) return;

    const leadMs = notificationSettings.leadTimeMinutes * 60000;
    const nowMs = currentTime.getTime();

    // Check Morning Golden Hour
    if (
      notificationSettings.goldenHourMorning &&
      solarTimes.goldenHourDawnStart
    ) {
      const triggerTime = solarTimes.goldenHourDawnStart.getTime() - leadMs;
      // If within 60 seconds of trigger time
      if (
        Math.abs(nowMs - triggerTime) <= 60000 &&
        lastFiredPhaseRef.current !== 'golden_dawn'
      ) {
        lastFiredPhaseRef.current = 'golden_dawn';
        const msg =
          leadMs > 0
            ? `Morning Golden Hour begins in ${notificationSettings.leadTimeMinutes} minutes!`
            : 'Morning Golden Hour is starting right now!';
        triggerNotification('Morning Golden Hour Alert', msg, notificationSettings.soundEnabled);
      }
    }

    // Check Evening Golden Hour
    if (
      notificationSettings.goldenHourEvening &&
      solarTimes.goldenHourDuskStart
    ) {
      const triggerTime = solarTimes.goldenHourDuskStart.getTime() - leadMs;
      if (
        Math.abs(nowMs - triggerTime) <= 60000 &&
        lastFiredPhaseRef.current !== 'golden_dusk'
      ) {
        lastFiredPhaseRef.current = 'golden_dusk';
        const msg =
          leadMs > 0
            ? `Evening Golden Hour begins in ${notificationSettings.leadTimeMinutes} minutes!`
            : 'Evening Golden Hour is starting right now!';
        triggerNotification('Evening Golden Hour Alert', msg, notificationSettings.soundEnabled);
      }
    }
  }, [currentTime, isLive, notificationSettings, solarTimes]);

  // Handlers
  const handleSelectLocation = (loc: LocationData) => {
    setActiveLocation(loc);
    saveActiveLocation(loc);
  };

  const handleToggleFavorite = (loc: LocationData) => {
    let updated: LocationData[];
    const exists = favorites.some(
      (f) =>
        f.name === loc.name ||
        (f.latitude === loc.latitude && f.longitude === loc.longitude)
    );
    if (exists) {
      updated = favorites.filter((f) => f.name !== loc.name);
    } else {
      updated = [...favorites, { ...loc, isFavorite: true }];
    }
    setFavorites(updated);
    saveFavoriteLocations(updated);
  };

  const handleToggleThemePreference = () => {
    const next: ThemePreference =
      themePreference === 'auto'
        ? 'dark'
        : themePreference === 'dark'
        ? 'light'
        : 'auto';
    setThemePreference(next);
    saveThemePreference(next);
  };

  const handleUpdateNotificationSettings = (newSettings: NotificationSettings) => {
    setNotificationSettings(newSettings);
    saveNotificationSettings(newSettings);
  };

  const handleTimeScrub = (newDate: Date) => {
    setIsLive(false);
    setCurrentTime(newDate);
  };

  const handleResetToLive = () => {
    setIsLive(true);
    setCurrentTime(new Date());
  };

  // Generate subtle background star coordinates for night sky
  const stars = useMemo(() => {
    const starList = [];
    for (let i = 0; i < 40; i++) {
      starList.push({
        x: (i * 29) % 100,
        y: (i * 17) % 65,
        size: (i % 3) + 1,
        opacity: 0.2 + ((i % 5) * 0.15),
      });
    }
    return starList;
  }, []);

  return (
    <div
      className="min-h-screen relative overflow-x-hidden transition-all duration-700 ease-in-out flex flex-col justify-between"
      style={{
        background: dynamicTheme.backgroundGradient,
        color: dynamicTheme.textPrimary,
      }}
    >
      {/* Sky atmospheric lighting overlay */}
      <div
        className="fixed inset-0 pointer-events-none transition-opacity duration-700 z-0"
        style={{ background: dynamicTheme.skyOverlayGradient }}
      />

      {/* Subtle night stars (rendered when solar elevation < -6°) */}
      {solarPosition.elevation < -6 && (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          {stars.map((star, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-white transition-opacity duration-1000"
              style={{
                left: `${star.x}%`,
                top: `${star.y}%`,
                width: `${star.size}px`,
                height: `${star.size}px`,
                opacity: star.opacity * Math.min(1, Math.abs(solarPosition.elevation) / 18),
                boxShadow: star.size > 2 ? '0 0 4px #ffffff' : 'none',
              }}
            />
          ))}
        </div>
      )}

      {/* Main App Content Container */}
      <div className="relative z-10 flex flex-col flex-1">
        {/* Sticky Header Top Bar */}
        <div className="sticky top-0 z-30 backdrop-blur-md border-b border-white/5">
          <Header
            location={activeLocation}
            onOpenLocationModal={() => setIsLocationModalOpen(true)}
            onOpenNotificationModal={() => setIsNotificationModalOpen(true)}
            notificationsEnabled={notificationSettings.enabled}
            themePreference={themePreference}
            onToggleTheme={handleToggleThemePreference}
            theme={dynamicTheme}
            isWidgetActive={showWidgetStudio}
            onToggleWidget={() => setShowWidgetStudio(!showWidgetStudio)}
          />
        </div>

        {/* Core Layout Grid */}
        <main className="max-w-6xl mx-auto w-full px-4 sm:px-6 py-6 space-y-6 flex-1">
          {/* One UI 9 Widget Studio (When toggled) */}
          {showWidgetStudio && (
            <div className="animate-fadeIn">
              <OneUIWidget
                solarTimes={solarTimes}
                solarPosition={solarPosition}
                currentPhaseInfo={currentPhaseInfo}
                location={activeLocation}
                currentTime={currentTime}
                theme={dynamicTheme}
                onClose={() => setShowWidgetStudio(false)}
              />
            </div>
          )}

          {/* Top Banner: Golden Hour Countdown & Alert Status */}
          <GoldenHourBanner
            solarTimes={solarTimes}
            currentTime={currentTime}
            theme={dynamicTheme}
            notificationsEnabled={notificationSettings.enabled}
            onToggleNotification={() => {
              const next = !notificationSettings.enabled;
              handleUpdateNotificationSettings({
                ...notificationSettings,
                enabled: next,
              });
            }}
          />

          {/* Central Grid: Solar Arc + Quick Telemetry */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
            {/* 2-Column Wide: Visual Solar Trajectory Arc */}
            <div className="lg:col-span-2 flex">
              <SolarArc
                solarPosition={solarPosition}
                solarTimes={solarTimes}
                theme={dynamicTheme}
                currentTime={currentTime}
              />
            </div>

            {/* 1-Column: Quick Metrics & Coordinates Card */}
            <div
              className="rounded-3xl p-5 md:p-6 backdrop-blur-xl border transition-all shadow-md flex flex-col justify-between"
              style={{
                backgroundColor: dynamicTheme.surface,
                borderColor: dynamicTheme.cardBorder,
              }}
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" style={{ color: dynamicTheme.primary }} />
                    <h3 className="text-sm font-semibold tracking-wide">Coordinates & Transit</h3>
                  </div>
                  <button
                    onClick={() => setIsLocationModalOpen(true)}
                    className="text-xs hover:underline cursor-pointer opacity-80"
                    style={{ color: dynamicTheme.primary }}
                  >
                    Change
                  </button>
                </div>

                <div className="space-y-3">
                  <div
                    className="p-3 rounded-2xl border"
                    style={{
                      backgroundColor: dynamicTheme.surfaceContainer,
                      borderColor: dynamicTheme.cardBorder,
                    }}
                  >
                    <span className="text-[11px] text-slate-400 block">Latitude & Longitude</span>
                    <span className="text-sm font-mono-numbers font-bold">
                      {activeLocation.latitude >= 0 ? `${activeLocation.latitude}° N` : `${Math.abs(activeLocation.latitude)}° S`},{' '}
                      {activeLocation.longitude >= 0 ? `${activeLocation.longitude}° E` : `${Math.abs(activeLocation.longitude)}° W`}
                    </span>
                  </div>

                  <div
                    className="p-3 rounded-2xl border flex items-center justify-between"
                    style={{
                      backgroundColor: dynamicTheme.surfaceContainer,
                      borderColor: dynamicTheme.cardBorder,
                    }}
                  >
                    <div>
                      <span className="text-[11px] text-slate-400 block">Sun Distance</span>
                      <span className="text-sm font-mono-numbers font-bold">
                        {solarPosition.distanceAU.toFixed(3)} AU
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">~149.6M km</span>
                  </div>

                  <div
                    className="p-3 rounded-2xl border flex items-center justify-between"
                    style={{
                      backgroundColor: dynamicTheme.surfaceContainer,
                      borderColor: dynamicTheme.cardBorder,
                    }}
                  >
                    <div>
                      <span className="text-[11px] text-slate-400 block">Solar Midnight (Nadir)</span>
                      <span className="text-sm font-mono-numbers font-bold">
                        {formatSolarTime(solarTimes.nadir)}
                      </span>
                    </div>
                    <Moon className="w-4 h-4 text-indigo-400" />
                  </div>
                </div>
              </div>

              {/* Informative Guidance */}
              <div className="mt-4 pt-3 border-t border-white/5 flex items-start gap-2 text-[11px] text-slate-400 leading-relaxed">
                <Info className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                <span>
                  All calculations run directly in your browser using NOAA astronomical equations. No network latency, works 100% offline.
                </span>
              </div>
            </div>
          </div>

          {/* Interactive 24-Hour Scrubber */}
          <TimeScrubber
            currentTime={currentTime}
            onChangeTime={handleTimeScrub}
            isLive={isLive}
            onResetToLive={handleResetToLive}
            solarTimes={solarTimes}
            currentPhaseInfo={currentPhaseInfo}
            theme={dynamicTheme}
          />

          {/* Full Solar Timeline Cards (Swipeable Carousel right below Scrubber) */}
          <PhaseCardList
            solarTimes={solarTimes}
            currentPhase={currentPhaseInfo.phase}
            currentTime={currentTime}
            theme={dynamicTheme}
            onSelectTime={handleTimeScrub}
          />
        </main>

        {/* Quiet Footer */}
        <footer className="w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400 mt-8">
          <div className="flex items-center gap-2">
            <span className="font-semibold" style={{ color: dynamicTheme.textPrimary }}>
              Spunky Sun Chasing
            </span>
            <span>·</span>
            <span>Material You 3</span>
            <span>·</span>
            <span>NOAA Astronomical Math</span>
          </div>
          <div>
            <span>100% Client-Side & Offline Ready</span>
          </div>
        </footer>
      </div>

      {/* Floating Offline Indicator */}
      <OfflineIndicator />

      {/* Modals */}
      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        activeLocation={activeLocation}
        onSelectLocation={handleSelectLocation}
        favorites={favorites}
        onToggleFavorite={handleToggleFavorite}
        theme={dynamicTheme}
      />

      <NotificationModal
        isOpen={isNotificationModalOpen}
        onClose={() => setIsNotificationModalOpen(false)}
        settings={notificationSettings}
        onUpdateSettings={handleUpdateNotificationSettings}
        theme={dynamicTheme}
      />

      {/* Floating In-App Live Push Notification Toast Banner */}
      <NotificationToast theme={dynamicTheme} />
    </div>
  );
}
