import React, { useState } from 'react';
import {
  Sun,
  Moon,
  SunMedium,
  Bell,
  MapPin,
  Sparkles,
  Layers,
  Menu,
  X,
  Download,
  Settings,
  ChevronRight,
  Package,
  FileCode
} from 'lucide-react';
import { LocationData } from '../utils/storage';
import { ThemePreference, DynamicTheme } from '../utils/themeEngine';
import { PWAInstallButton } from './PWAInstallButton';

interface HeaderProps {
  location: LocationData;
  onOpenLocationModal: () => void;
  onOpenNotificationModal: () => void;
  notificationsEnabled: boolean;
  themePreference: ThemePreference;
  onToggleTheme: () => void;
  theme: DynamicTheme;
  isWidgetActive: boolean;
  onToggleWidget: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  location,
  onOpenLocationModal,
  onOpenNotificationModal,
  notificationsEnabled,
  themePreference,
  onToggleTheme,
  theme,
  isWidgetActive,
  onToggleWidget,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <>
      <header className="w-full flex items-center justify-between gap-2 sm:gap-4 px-3 sm:px-6 py-2.5 sm:py-3.5 z-30 transition-colors">
        {/* Left: Brand Wordmark (Compact on mobile) */}
        <div className="flex items-center gap-2 shrink-0">
          <div
            className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl flex items-center justify-center shadow-sm shrink-0"
            style={{ backgroundColor: theme.primary, color: theme.onPrimary }}
          >
            <Sun className="w-4 h-4 sm:w-5 sm:h-5" />
          </div>
          <span
            className="text-base sm:text-lg font-bold tracking-tight font-display whitespace-nowrap"
            style={{ color: theme.textPrimary }}
          >
            <span className="inline sm:hidden">Spunky Sun</span>
            <span className="hidden sm:inline">Spunky Sun Chasing</span>
          </span>
        </div>

        {/* Center: Perfectly Aligned Location Pill */}
        <button
          onClick={onOpenLocationModal}
          aria-label="Change location"
          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full text-xs font-medium backdrop-blur-md transition-all cursor-pointer border max-w-[140px] sm:max-w-xs shrink"
          style={{
            backgroundColor: theme.surfaceContainer,
            borderColor: theme.cardBorder,
            color: theme.textPrimary,
          }}
        >
          <div className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 bg-amber-500/20 text-amber-400">
            <MapPin className="w-3 h-3" />
          </div>
          <span className="truncate font-medium text-[11px] sm:text-xs">{location.name}</span>
        </button>

        {/* Right: Actions Cluster */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Notification bell button (Always accessible on all screen sizes) */}
          <button
            onClick={onOpenNotificationModal}
            aria-label="Notification alert settings"
            title="Notification alert settings"
            className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-full transition-all cursor-pointer border"
            style={{
              backgroundColor: theme.surfaceContainer,
              borderColor: theme.cardBorder,
              color: theme.textPrimary,
            }}
          >
            <Bell className="w-4 h-4" />
            {notificationsEnabled && (
              <span
                className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
                style={{ backgroundColor: theme.primary }}
                title="Notifications active"
              />
            )}
          </button>

          {/* Desktop-only Quick Actions */}
          <div className="hidden lg:flex items-center gap-2">
            <button
              onClick={onToggleWidget}
              aria-label="One UI 9 Widget Studio"
              title="Samsung One UI 9 Widget Studio & Floating PiP"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all"
              style={{
                backgroundColor: isWidgetActive ? theme.primary : theme.surfaceContainer,
                color: isWidgetActive ? theme.onPrimary : theme.textPrimary,
                borderColor: theme.cardBorder,
              }}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>One UI 9</span>
            </button>

            <PWAInstallButton isDark={theme.isDark} />

            <button
              onClick={onToggleTheme}
              aria-label={`Theme mode: ${themePreference}. Click to toggle.`}
              title={`Theme: ${themePreference.toUpperCase()} (Click to toggle)`}
              className="w-9 h-9 flex items-center justify-center rounded-full transition-all cursor-pointer border"
              style={{
                backgroundColor: theme.surfaceContainer,
                borderColor: theme.cardBorder,
                color: theme.textPrimary,
              }}
            >
              {themePreference === 'auto' ? (
                <Sparkles className="w-4 h-4 text-amber-400" />
              ) : themePreference === 'light' ? (
                <SunMedium className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-300" />
              )}
            </button>
          </div>

          {/* Mobile & Tablet One UI Menu Trigger Button */}
          <button
            onClick={() => setIsMenuOpen(true)}
            aria-label="Open settings and options menu"
            title="App Menu & Settings"
            className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-full transition-all cursor-pointer border"
            style={{
              backgroundColor: theme.surfaceContainer,
              borderColor: theme.cardBorder,
              color: theme.textPrimary,
            }}
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Samsung One UI 9 Slide-Up Mobile Menu Drawer */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md p-0 sm:p-4 animate-in fade-in duration-200">
          <div
            className="w-full sm:max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl border transition-all max-h-[85vh] overflow-y-auto bg-[#0c1322] border-slate-700 text-white"
          >
            {/* Drawer Handle (Mobile) */}
            <div className="w-12 h-1.5 rounded-full bg-slate-600 mx-auto mb-4 sm:hidden" />

            {/* Menu Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 mb-4">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8 h-8 rounded-2xl bg-sky-600 text-white flex items-center justify-center shadow-md"
                >
                  <Settings className="w-4 h-4" />
                </div>
                <h3 className="text-base font-bold tracking-tight text-white font-display">Menu & Controls</h3>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-1 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                aria-label="Close menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Menu Items List */}
            <div className="space-y-3 text-xs">
              {/* 1. Theme Toggle Row */}
              <div
                className="p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    {themePreference === 'auto' ? (
                      <Sparkles className="w-4 h-4" />
                    ) : themePreference === 'light' ? (
                      <SunMedium className="w-4 h-4" />
                    ) : (
                      <Moon className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">Theme Mode</span>
                    <span className="text-slate-300 text-[11px] capitalize">
                      Current: {themePreference} {themePreference === 'auto' && '(Follows Sun)'}
                    </span>
                  </div>
                </div>

                <button
                  onClick={onToggleTheme}
                  className="px-3.5 py-1.5 rounded-xl font-bold transition-all border border-sky-400/40 bg-sky-600 hover:bg-sky-500 text-white cursor-pointer capitalize shadow-sm"
                >
                  Toggle ({themePreference})
                </button>
              </div>

              {/* 2. Notification Alert Settings */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenNotificationModal();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between transition-all hover:bg-slate-700/60 cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">Golden Hour Alerts</span>
                    <span className="text-slate-300 text-[11px] block">
                      {notificationsEnabled ? 'Alerts Active (Chimes & Notifications)' : 'Tap to configure alerts'}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </button>

              {/* 3. Samsung One UI 9 Widget Studio */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onToggleWidget();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between transition-all hover:bg-slate-700/60 cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">One UI 9 Widget Studio</span>
                    <span className="text-slate-300 text-[11px] block">
                      {isWidgetActive ? 'Hide Widget Studio' : 'Preview widgets & Floating PiP'}
                    </span>
                  </div>
                </div>
                <span
                  className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase shrink-0 bg-sky-500/20 text-sky-300 border border-sky-400/30"
                >
                  {isWidgetActive ? 'Active' : 'Open'}
                </span>
              </button>

              {/* 4. Location & GPS Settings */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenLocationModal();
                }}
                className="w-full p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between transition-all hover:bg-slate-700/60 cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">Location / Coordinates</span>
                    <span className="text-slate-300 text-[11px] truncate max-w-[200px] block">
                      {location.name}
                    </span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </button>

              {/* 5. Download Native Android Widget Package (.zip) */}
              <a
                href="/android-native-widget-package.zip"
                download="android-native-widget-package.zip"
                className="w-full p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between transition-all hover:bg-slate-700/60 cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                    <Package className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">Download Native Widget Files</span>
                    <span className="text-slate-300 text-[11px] block">
                      Kotlin provider, One UI XML layouts (.zip)
                    </span>
                  </div>
                </div>
                <Download className="w-4 h-4 text-amber-400 shrink-0" />
              </a>

              {/* 6. Download Full Project Codebase (.zip) */}
              <a
                href="/spunky-sun-chasing-full-project.zip"
                download="spunky-sun-chasing-full-project.zip"
                className="w-full p-3.5 rounded-2xl border border-slate-700/80 bg-slate-800/80 flex items-center justify-between transition-all hover:bg-slate-700/60 cursor-pointer text-left"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                    <FileCode className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold block text-sm text-white">Download Full Project</span>
                    <span className="text-slate-300 text-[11px] block">
                      Complete source for Cursor & Android Studio (.zip)
                    </span>
                  </div>
                </div>
                <Download className="w-4 h-4 text-blue-400 shrink-0" />
              </a>

              {/* 7. Mobile Install / APK Button */}
              <div className="pt-2">
                <PWAInstallButton isDark={theme.isDark} />
              </div>
            </div>

            <button
              onClick={() => setIsMenuOpen(false)}
              className="mt-5 w-full py-2.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
