import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Clock } from 'lucide-react';
import { SolarTimes, SolarPhaseInfo } from '../utils/solarMath';
import { DynamicTheme } from '../utils/themeEngine';

interface TimeScrubberProps {
  currentTime: Date;
  onChangeTime: (time: Date) => void;
  isLive: boolean;
  onResetToLive: () => void;
  solarTimes: SolarTimes;
  currentPhaseInfo: SolarPhaseInfo;
  theme: DynamicTheme;
}

export const TimeScrubber: React.FC<TimeScrubberProps> = ({
  currentTime,
  onChangeTime,
  isLive,
  onResetToLive,
  solarTimes,
  currentPhaseInfo,
  theme,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const playIntervalRef = useRef<number | null>(null);

  // Minutes from midnight (0 to 1439)
  const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();

  // Handle manual scrub
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const minutes = parseInt(e.target.value, 10);
    const newDate = new Date(currentTime);
    newDate.setHours(Math.floor(minutes / 60));
    newDate.setMinutes(minutes % 60);
    newDate.setSeconds(0);
    onChangeTime(newDate);
  };

  const currentTimeRef = useRef(currentTime);
  currentTimeRef.current = currentTime;

  // Play / simulate full day cycle
  useEffect(() => {
    if (isPlaying) {
      playIntervalRef.current = window.setInterval(() => {
        const next = new Date(currentTimeRef.current.getTime() + 10 * 60000); // advance 10 minutes per tick
        onChangeTime(next);
      }, 100);
    } else if (playIntervalRef.current) {
      clearInterval(playIntervalRef.current);
    }
    return () => {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
    };
  }, [isPlaying, onChangeTime]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
  };

  // Calculate percentages along the 24h track for sunrise & sunset
  const getPercent = (date: Date | null) => {
    if (!date) return 0;
    const mins = date.getHours() * 60 + date.getMinutes();
    return (mins / 1440) * 100;
  };

  const sunrisePercent = getPercent(solarTimes.sunrise);
  const sunsetPercent = getPercent(solarTimes.sunset);
  const goldenDawnPercent = getPercent(solarTimes.goldenHourDawnStart);
  const goldenDuskPercent = getPercent(solarTimes.goldenHourDuskStart);

  return (
    <div
      className="w-full rounded-3xl p-5 md:p-6 backdrop-blur-xl border transition-all shadow-md"
      style={{
        backgroundColor: theme.surface,
        borderColor: theme.cardBorder,
        color: theme.textPrimary,
      }}
    >
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4" style={{ color: theme.primary }} />
          <h3 className="text-sm font-semibold tracking-wide">24-Hour Time Scrubber</h3>
          <span
            className="px-2.5 py-0.5 rounded-full text-xs font-semibold"
            style={{
              backgroundColor: theme.primaryContainer,
              color: theme.onPrimaryContainer,
            }}
          >
            {currentPhaseInfo.name}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Play / pause day simulation */}
          <button
            onClick={togglePlay}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer transition-all border"
            style={{
              backgroundColor: isPlaying ? theme.primary : theme.surfaceContainer,
              color: isPlaying ? theme.onPrimary : theme.textPrimary,
              borderColor: theme.cardBorder,
            }}
            title={isPlaying ? 'Pause simulation' : 'Play 24-hour simulation'}
          >
            {isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Simulate Day</span>
              </>
            )}
          </button>

          {/* Snap to real-time Now */}
          <button
            onClick={onResetToLive}
            disabled={isLive && !isPlaying}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
              isLive && !isPlaying
                ? 'opacity-50 cursor-default'
                : 'cursor-pointer hover:opacity-90'
            }`}
            style={{
              backgroundColor: theme.surfaceContainer,
              borderColor: theme.cardBorder,
              color: theme.textPrimary,
            }}
            title="Snap back to current real-time clock"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Live Now</span>
          </button>
        </div>
      </div>

      {/* Scrubber slider track with solar phase markers */}
      <div className="relative pt-6 pb-2">
        {/* Visual daylight bar on track */}
        <div className="absolute top-8 left-0 right-0 h-2 rounded-full overflow-hidden bg-black/25">
          {/* Daylight window */}
          {sunrisePercent > 0 && sunsetPercent > 0 && (
            <div
              className="absolute top-0 bottom-0 bg-sky-400/60"
              style={{
                left: `${sunrisePercent}%`,
                width: `${Math.max(0, sunsetPercent - sunrisePercent)}%`,
              }}
            />
          )}
          {/* Golden dawn marker */}
          {goldenDawnPercent > 0 && (
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-amber-400"
              style={{ left: `${goldenDawnPercent}%` }}
              title="Morning Golden Hour"
            />
          )}
          {/* Golden dusk marker */}
          {goldenDuskPercent > 0 && (
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-amber-500"
              style={{ left: `${goldenDuskPercent}%` }}
              title="Evening Golden Hour"
            />
          )}
        </div>

        {/* Input range slider */}
        <input
          type="range"
          min="0"
          max="1439"
          value={currentMinutes}
          onChange={handleSliderChange}
          className="relative w-full h-6 z-10 cursor-pointer"
          style={{ color: theme.primary }}
          aria-label="Time of day scrubber"
        />

        {/* Time markers along the scrubber */}
        <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono-numbers mt-1 select-none">
          <span>00:00</span>
          <span>06:00 (Dawn)</span>
          <span>12:00 (Noon)</span>
          <span>18:00 (Dusk)</span>
          <span>23:59</span>
        </div>
      </div>

      {/* Selected Time Display */}
      <div className="flex items-center justify-between text-xs mt-2 pt-2 border-t border-white/5">
        <span className="text-slate-400">
          {isLive ? 'Real-Time Clock' : 'Simulated Time Preview'}
        </span>
        <span
          className="text-base font-bold font-mono-numbers tracking-wider"
          style={{ color: theme.primary }}
        >
          {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
        </span>
      </div>
    </div>
  );
};
