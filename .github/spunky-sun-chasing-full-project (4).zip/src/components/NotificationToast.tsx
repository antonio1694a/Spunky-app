import React, { useState, useEffect } from 'react';
import { Sparkles, Bell, X, Volume2 } from 'lucide-react';
import { subscribeNotification } from '../utils/notifications';
import { DynamicTheme } from '../utils/themeEngine';

interface ToastItem {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
}

export const NotificationToast: React.FC<{ theme: DynamicTheme }> = ({ theme }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  useEffect(() => {
    const unsubscribe = subscribeNotification((title, message) => {
      const newToast: ToastItem = {
        id: `toast-${Date.now()}-${Math.random()}`,
        title,
        message,
        timestamp: new Date(),
      };

      setToasts((prev) => [newToast, ...prev].slice(0, 3)); // show max 3

      // Auto dismiss after 6 seconds
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
      }, 6000);
    });

    return unsubscribe;
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-md px-4 flex flex-col gap-2.5 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto rounded-3xl p-4 shadow-2xl border backdrop-blur-2xl transition-all duration-300 animate-in fade-in slide-in-from-top-4 flex items-start justify-between gap-3"
          style={{
            backgroundColor: 'rgba(15, 23, 42, 0.88)',
            borderColor: '#f59e0b',
            color: '#ffffff',
          }}
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 shadow-inner">
              <Sparkles className="w-5 h-5 animate-pulse" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                  Live Alert
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {toast.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <h4 className="text-sm font-bold text-white tracking-tight mt-0.5">
                {toast.title}
              </h4>
              <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                {toast.message}
              </p>
            </div>
          </div>

          <button
            onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
            className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            aria-label="Dismiss alert"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
