import React, { useState } from 'react';
import { X, Navigation, Search, Heart, MapPin, Check, Plus } from 'lucide-react';
import { LocationData, OFFLINE_LOCATIONS } from '../utils/storage';
import { DynamicTheme } from '../utils/themeEngine';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeLocation: LocationData;
  onSelectLocation: (loc: LocationData) => void;
  favorites: LocationData[];
  onToggleFavorite: (loc: LocationData) => void;
  theme: DynamicTheme;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  activeLocation,
  onSelectLocation,
  favorites,
  onToggleFavorite,
  theme,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  // Manual coordinate input states
  const [manualLat, setManualLat] = useState(activeLocation.latitude.toString());
  const [manualLng, setManualLng] = useState(activeLocation.longitude.toString());
  const [manualName, setManualName] = useState(activeLocation.name);
  const [manualError, setManualError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Use Device GPS
  const handleUseGPS = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      return;
    }

    setGpsLoading(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsLoading(false);
        const lat = Math.round(pos.coords.latitude * 10000) / 10000;
        const lng = Math.round(pos.coords.longitude * 10000) / 10000;
        const gpsLoc: LocationData = {
          id: `gps-${Date.now()}`,
          name: 'My Current Location (GPS)',
          country: 'Local GPS',
          latitude: lat,
          longitude: lng,
          isCustom: true,
        };
        onSelectLocation(gpsLoc);
        onClose();
      },
      (err) => {
        setGpsLoading(false);
        if (err.code === err.PERMISSION_DENIED) {
          setGpsError('Location permission was denied. You can enter coordinates manually below.');
        } else if (err.code === err.TIMEOUT) {
          setGpsError('GPS request timed out. Please try again or enter coordinates manually.');
        } else {
          setGpsError('Unable to retrieve your location. Please enter coordinates manually.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      }
    );
  };

  // Submit manual coordinates
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setManualError(null);

    const lat = parseFloat(manualLat);
    const lng = parseFloat(manualLng);

    if (isNaN(lat) || lat < -90 || lat > 90) {
      setManualError('Latitude must be a valid number between -90 and +90.');
      return;
    }

    if (isNaN(lng) || lng < -180 || lng > 180) {
      setManualError('Longitude must be a valid number between -180 and +180.');
      return;
    }

    const customLoc: LocationData = {
      id: `custom-${Date.now()}`,
      name: manualName.trim() || `Coord: ${lat.toFixed(2)}°, ${lng.toFixed(2)}°`,
      country: 'Custom Coordinates',
      latitude: Math.round(lat * 10000) / 10000,
      longitude: Math.round(lng * 10000) / 10000,
      isCustom: true,
    };

    onSelectLocation(customLoc);
    onClose();
  };

  // Filtered preloaded offline locations
  const filteredLocations = OFFLINE_LOCATIONS.filter((loc) => {
    const q = searchQuery.toLowerCase();
    return (
      loc.name.toLowerCase().includes(q) ||
      loc.country.toLowerCase().includes(q) ||
      (loc.region && loc.region.toLowerCase().includes(q))
    );
  });

  const isFavorite = (loc: LocationData) => {
    return favorites.some((f) => f.name === loc.name || (f.latitude === loc.latitude && f.longitude === loc.longitude));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 overflow-y-auto">
      <div
        className="w-full max-w-lg rounded-3xl p-6 shadow-2xl border transition-all max-h-[90vh] flex flex-col my-auto"
        style={{
          backgroundColor: theme.surface,
          borderColor: theme.cardBorder,
          color: theme.textPrimary,
        }}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" style={{ color: theme.primary }} />
            <h3 className="text-base font-bold tracking-tight font-display">Select Location or Coordinates</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 py-4 space-y-5 pr-1">
          {/* GPS Quick Button */}
          <div className="flex flex-col gap-1.5">
            <button
              onClick={handleUseGPS}
              disabled={gpsLoading}
              className="w-full py-3 px-4 rounded-2xl flex items-center justify-center gap-2 text-xs font-semibold tracking-wide cursor-pointer shadow-sm transition-all active:scale-[0.99]"
              style={{
                backgroundColor: theme.primary,
                color: theme.onPrimary,
              }}
            >
              <Navigation className={`w-4 h-4 ${gpsLoading ? 'animate-spin' : ''}`} />
              <span>{gpsLoading ? 'Locating via GPS...' : 'Use Current Device GPS'}</span>
            </button>
            {gpsError && (
              <p className="text-xs text-rose-400 mt-1 px-1">{gpsError}</p>
            )}
          </div>

          {/* Favorites Strip */}
          {favorites.length > 0 && (
            <div>
              <span className="text-xs font-semibold text-slate-400 block mb-2">Saved Favorites</span>
              <div className="flex flex-wrap gap-2">
                {favorites.map((fav) => (
                  <button
                    key={fav.id}
                    onClick={() => {
                      onSelectLocation(fav);
                      onClose();
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all cursor-pointer hover:border-amber-400"
                    style={{
                      backgroundColor: theme.surfaceContainer,
                      borderColor: theme.cardBorder,
                      color: theme.textPrimary,
                    }}
                  >
                    <Heart className="w-3 h-3 fill-rose-500 text-rose-500" />
                    <span>{fav.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Manual Coordinates Form */}
          <form onSubmit={handleManualSubmit} className="p-4 rounded-2xl border space-y-3" style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Manual Coordinates</span>
              <span className="text-[10px] text-slate-400">GPS Degrees (WGS84)</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Latitude (-90 to +90)</label>
                <input
                  type="number"
                  step="any"
                  value={manualLat}
                  onChange={(e) => setManualLat(e.target.value)}
                  placeholder="e.g. 37.7749"
                  className="w-full px-3 py-2 rounded-xl text-xs font-mono-numbers bg-black/20 border border-white/10 focus:outline-none focus:ring-1 focus:ring-amber-400"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Longitude (-180 to +180)</label>
                <input
                  type="number"
                  step="any"
                  value={manualLng}
                  onChange={(e) => setManualLng(e.target.value)}
                  placeholder="e.g. -122.4194"
                  className="w-full px-3 py-2 rounded-xl text-xs font-mono-numbers bg-black/20 border border-white/10 focus:outline-none focus:ring-1 focus:ring-amber-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Location Label (Optional)</label>
              <input
                type="text"
                value={manualName}
                onChange={(e) => setManualName(e.target.value)}
                placeholder="e.g. Mountain Summit, Beach Camp, Golden Gate"
                className="w-full px-3 py-2 rounded-xl text-xs bg-black/20 border border-white/10 focus:outline-none focus:ring-1 focus:ring-amber-400"
              />
            </div>

            {manualError && (
              <p className="text-xs text-rose-400">{manualError}</p>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5"
              style={{
                backgroundColor: theme.primaryContainer,
                color: theme.onPrimaryContainer,
              }}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Set Custom Coordinates</span>
            </button>
          </form>

          {/* Search Offline Cities */}
          <div className="space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Offline Global Locations</span>
            
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search city, region, or country..."
                className="w-full pl-9 pr-3 py-2 rounded-xl text-xs bg-black/20 border border-white/10 focus:outline-none focus:ring-1 focus:ring-amber-400"
              />
            </div>

            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
              {filteredLocations.map((loc) => {
                const fav = isFavorite(loc);
                const isSelected = activeLocation.name === loc.name;

                return (
                  <div
                    key={loc.id}
                    className={`flex items-center justify-between p-2.5 rounded-2xl border transition-all ${
                      isSelected ? 'ring-1 ring-amber-400' : 'hover:bg-white/5'
                    }`}
                    style={{
                      backgroundColor: isSelected ? theme.surfaceContainerHigh : theme.surfaceContainer,
                      borderColor: theme.cardBorder,
                    }}
                  >
                    <button
                      onClick={() => {
                        onSelectLocation(loc);
                        onClose();
                      }}
                      className="flex-1 text-left cursor-pointer flex items-center gap-2"
                    >
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <div className="truncate">
                        <div className="text-xs font-semibold truncate">{loc.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono-numbers">
                          {loc.country} · {loc.latitude.toFixed(2)}°, {loc.longitude.toFixed(2)}°
                        </div>
                      </div>
                    </button>

                    <div className="flex items-center gap-1">
                      {isSelected && (
                        <Check className="w-4 h-4 text-amber-400 mr-1" />
                      )}
                      <button
                        onClick={() => onToggleFavorite(loc)}
                        className="p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
                        title={fav ? 'Remove from favorites' : 'Add to favorites'}
                        aria-label="Toggle favorite"
                      >
                        <Heart
                          className={`w-3.5 h-3.5 ${
                            fav ? 'fill-rose-500 text-rose-500' : 'text-slate-400'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                );
              })}

              {filteredLocations.length === 0 && (
                <div className="text-center py-6 text-xs text-slate-400">
                  No matching preloaded cities. Enter coordinates manually above.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
