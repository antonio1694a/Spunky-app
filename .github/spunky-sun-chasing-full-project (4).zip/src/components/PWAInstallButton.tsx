import React, { useState, useEffect } from 'react';
import { Download, Smartphone, Package, ExternalLink, X, Sun, Check } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

interface PWAInstallButtonProps {
  isDark?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ isDark = true }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);

  useEffect(() => {
    // Check if already in standalone display mode
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as unknown as { standalone?: boolean }).standalone) {
      setIsInstalled(true);
    }

    const handleBeforePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforePrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforePrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        await deferredPrompt.prompt();
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          setIsInstalled(true);
        }
        setDeferredPrompt(null);
      } catch {
        setShowGuideModal(true);
      }
    } else {
      setShowGuideModal(true);
    }
  };

  if (isInstalled) return null;

  const currentUrl = typeof window !== 'undefined'
    ? window.location.href
    : 'https://ais-dev-dwas6o43ehwtutjvovlzhj-726875453359.us-west2.run.app';

  const pwaBuilderUrl = `https://www.pwabuilder.com?site=${encodeURIComponent(currentUrl)}`;

  return (
    <>
      <button
        onClick={handleInstallClick}
        aria-label="Install Spunky Sun Chasing App or APK"
        title="Install Spunky Sun Chasing APK or Home Screen App"
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer whitespace-nowrap shrink-0 border ${
          isDark
            ? 'bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border-sky-400/30'
            : 'bg-sky-600/10 hover:bg-sky-600/20 text-sky-700 border-sky-500/20'
        }`}
      >
        <Download className="w-3.5 h-3.5 text-sky-400" />
        <span>Install / APK</span>
      </button>

      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div
            className="w-full sm:max-w-md rounded-t-[32px] sm:rounded-[32px] p-6 shadow-2xl border transition-all max-h-[85vh] flex flex-col bg-[#0c1322] border-slate-700 text-white"
          >
            {/* Mobile Drawer Handle */}
            <div className="w-12 h-1.5 rounded-full bg-slate-600 mx-auto mb-3 sm:hidden shrink-0" />

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-700/80 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-sky-600 text-white flex items-center justify-center shadow-md shrink-0">
                  <Sun className="w-5 h-5 text-sky-100" />
                </div>
                <div>
                  <h3 className="text-base font-bold tracking-tight text-white font-display">
                    Install Spunky Sun Chasing
                  </h3>
                  <p className="text-[11px] text-sky-400 font-medium">Samsung One UI & Android App</p>
                </div>
              </div>
              <button
                onClick={() => setShowGuideModal(false)}
                className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors cursor-pointer"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="py-4 space-y-3.5 overflow-y-auto text-xs leading-relaxed text-slate-200 pr-1">
              {/* Method 1: Instant Chrome / One UI App */}
              <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-bold text-white text-sm">Option 1: Add to Home Screen (Full Screen)</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Runs in 100% full-screen without Chrome address bars and with its own app icon:
                </p>
                <div className="space-y-1.5 text-slate-200 text-[11px] bg-slate-900/90 p-3 rounded-xl border border-slate-700/60">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold text-[10px]">1</span>
                    <span>Tap Chrome's menu (<strong className="text-white">⋮ 3 dots</strong> in top-right).</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold text-[10px]">2</span>
                    <span>Tap <strong className="text-amber-400">"Add to Home screen"</strong> or <strong className="text-amber-400">"Create shortcut"</strong>.</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center font-bold text-[10px]">3</span>
                    <span>Confirm name as <strong className="text-white">Spunky Sun</strong> and tap Add.</span>
                  </div>
                </div>
              </div>

              {/* Method 2: Download Native One UI Widget Code */}
              <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2.5">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-bold text-white text-sm">Option 2: Native One UI Widgets (.zip)</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Contains the Kotlin `SolisWidgetProvider`, One UI squircle XML layouts, and GitHub Actions cloud builder:
                </p>
                
                <a
                  href="/android-native-widget-package.zip"
                  download="android-native-widget-package.zip"
                  className="w-full py-2.5 px-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold flex items-center justify-center gap-2 transition-all cursor-pointer text-xs shadow-md"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Native Widget Package (.zip)</span>
                </a>
              </div>

              {/* Method 3: Cloud PWABuilder */}
              <div className="p-3.5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-2">
                <div className="flex items-center gap-2">
                  <ExternalLink className="w-4 h-4 text-sky-400 shrink-0" />
                  <span className="font-bold text-white text-sm">Option 3: Web-to-APK (PWABuilder)</span>
                </div>
                <a
                  href={pwaBuilderUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold flex items-center justify-center gap-2 transition-all cursor-pointer text-xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Open PWABuilder.com</span>
                </a>
              </div>
            </div>

            <button
              onClick={() => setShowGuideModal(false)}
              className="mt-3 w-full py-2.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer shrink-0"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
