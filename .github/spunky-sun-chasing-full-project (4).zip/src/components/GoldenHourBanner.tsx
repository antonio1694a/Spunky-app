import React, { useState, useEffect } from 'react';
import { Camera, Sparkles, Bell, BellRing, Play } from 'lucide-react';
import { SolarTimes, formatSolarTime } from '../utils/solarMath';
import { DynamicTheme } from '../utils/themeEngine';
import { triggerNotification, requestNotificationPermission, getNotificationPermission } from '../utils/notifications';

interface GoldenHourBannerProps {
  solarTimes: SolarTimes;
  currentTime: Date;
  theme: DynamicTheme;
  notificationsEnabled: boolean;
  onToggleNotification: () => void;
}

export const GoldenHourBanner: React.FC<GoldenHourBannerProps> = ({
  solarTimes,
  currentTime,
  theme,
  notificationsEnabled,
  onToggleNotification,
}) => {
  const [countdownText, setCountdownText] = useState<string>('');
  const [isActive, setIsActive] = useState<boolean>(false);
  const [activeType, setActiveType] = useState<'morning' | 'evening' | null>(null);
  const [nextEventName, setNextEventName] = useState<string>('');
  const [nextEventTime, setNextEventTime] = useState<Date | null>(null);
  const [testTriggered, setTestTriggered] = useState<boolean>(false);

  useEffect(() => {
    const nowMs = currentTime.getTime();

    // Check if morning golden hour is active
    const mornStart = solarTimes.goldenHourDawnStart?.getTime() ?? 0;
    const mornEnd = solarTimes.goldenHourDawnEnd?.getTime() ?? 0;

    // Check if evening golden hour is active
    const eveStart = solarTimes.goldenHourDuskStart?.getTime() ?? 0;
    const eveEnd = solarTimes.goldenHourDuskEnd?.getTime() ?? 0;

    if (nowMs >= mornStart && nowMs <= mornEnd) {
      setIsActive(true);
      setActiveType('morning');
      const remainingSec = Math.max(0, Math.floor((mornEnd - nowMs) / 1000));
      const m = Math.floor(remainingSec / 60);
      const s = remainingSec % 60;
      setCountdownText(`Ends in ${m}m ${s < 10 ? '0' : ''}${s}s`);
      return;
    }

    if (nowMs >= eveStart && nowMs <= eveEnd) {
      setIsActive(true);
      setActiveType('evening');
      const remainingSec = Math.max(0, Math.floor((eveEnd - nowMs) / 1000));
      const m = Math.floor(remainingSec / 60);
      const s = remainingSec % 60;
      setCountdownText(`Ends in ${m}m ${s < 10 ? '0' : ''}${s}s`);
      return;
    }

    // Otherwise, find the next golden hour
    setIsActive(false);
    setActiveType(null);

    let nextName = 'Morning Golden Hour';
    let nextTarget: Date | null = null;

    if (solarTimes.goldenHourDawnStart && nowMs < mornStart) {
      nextName = 'Morning Golden Hour';
      nextTarget = solarTimes.goldenHourDawnStart;
    } else if (solarTimes.goldenHourDuskStart && nowMs < eveStart) {
      nextName = 'Evening Golden Hour';
      nextTarget = solarTimes.goldenHourDuskStart;
    } else if (solarTimes.goldenHourDawnStart) {
      // Tomorrow morning
      nextName = 'Tomorrow Golden Dawn';
      nextTarget = new Date(solarTimes.goldenHourDawnStart.getTime() + 86400000);
    }

    setNextEventName(nextName);
    setNextEventTime(nextTarget);

    if (nextTarget) {
      const diffSec = Math.max(0, Math.floor((nextTarget.getTime() - nowMs) / 1000));
      const h = Math.floor(diffSec / 3600);
      const m = Math.floor((diffSec % 3600) / 60);
      const s = diffSec % 60;
      setCountdownText(`${h}h ${m < 10 ? '0' : ''}${m}m ${s < 10 ? '0' : ''}${s}s`);
    } else {
      setCountdownText('N/A (Polar location)');
    }
  }, [currentTime, solarTimes]);

  const handleTestAlert = async () => {
    const perm = getNotificationPermission();
    if (perm !== 'granted') {
      await requestNotificationPermission();
    }
    triggerNotification(
      'Golden Hour Alert!',
      'Golden Hour is starting now. Soft golden tones and long dramatic shadows are active.',
      true
    );
    setTestTriggered(true);
    setTimeout(() => setTestTriggered(false), 2500);
  };

  return (
    <div
      className="w-full rounded-3xl p-5 md:p-6 backdrop-blur-xl border transition-all shadow-md relative overflow-hidden"
      style={{
        backgroundColor: isActive ? 'rgba(245, 158, 11, 0.15)' : theme.surface,
        borderColor: isActive ? '#f59e0b' : theme.cardBorder,
        color: theme.textPrimary,
      }}
    >
      {/* Decorative ambient corner glow */}
      <div
        className="absolute -right-8 -top-8 w-32 h-32 rounded-full pointer-events-none opacity-30 blur-2xl"
        style={{ backgroundColor: isActive ? '#f59e0b' : theme.primary }}
      />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        {/* Left: Info & Status */}
        <div className="flex items-start gap-3.5">
          <div
            className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-sm transition-all ${
              isActive ? 'animate-pulse' : ''
            }`}
            style={{
              backgroundColor: isActive ? '#d97706' : theme.surfaceContainerHigh,
              color: isActive ? '#ffffff' : theme.primary,
            }}
          >
            {isActive ? <Sparkles className="w-6 h-6" /> : <Camera className="w-6 h-6" />}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-bold" style={{ color: isActive ? '#f59e0b' : theme.primary }}>
                {isActive ? 'Active Golden Hour' : 'Next Alert Target'}
              </span>
              {isActive && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                  LIVE
                </span>
              )}
            </div>

            <h3 className="text-lg md:text-xl font-bold tracking-tight font-display mt-0.5">
              {isActive ? (activeType === 'morning' ? 'Morning Golden Light' : 'Evening Golden Glow') : nextEventName}
            </h3>

            <p className="text-xs text-slate-400 mt-1 max-w-md">
              {isActive
                ? 'Prime photography window: 3200K–3600K color temperature, low-angle diffuse illumination, minimal harsh contrast.'
                : `Scheduled at ${formatSolarTime(nextEventTime)}. Ideal for portraits, landscapes, and architectural photography.`}
            </p>
          </div>
        </div>

        {/* Right: Countdown & Quick Controls */}
        <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto gap-2.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-0 border-white/10">
          <div className="flex flex-col sm:items-end">
            <span className="text-[11px] text-slate-400">
              {isActive ? 'Window Closes' : 'Begins In'}
            </span>
            <span
              className="text-xl md:text-2xl font-bold font-mono-numbers tracking-tight"
              style={{ color: isActive ? '#f59e0b' : theme.primary }}
            >
              {countdownText}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick alert toggle button */}
            <button
              onClick={onToggleNotification}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer transition-all border ${
                notificationsEnabled
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400 shadow-sm'
                  : 'bg-white/10 hover:bg-white/15 text-slate-200 border-white/15'
              }`}
              title={notificationsEnabled ? 'Alert enabled for golden hour' : 'Click to enable alert'}
            >
              {notificationsEnabled ? (
                <>
                  <BellRing className="w-3.5 h-3.5" />
                  <span>Alert Active</span>
                </>
              ) : (
                <>
                  <Bell className="w-3.5 h-3.5" />
                  <span>Enable Alert</span>
                </>
              )}
            </button>

            {/* Test Chime Trigger */}
            <button
              onClick={handleTestAlert}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-xs font-medium bg-white/10 hover:bg-white/20 text-slate-300 border border-white/15 cursor-pointer transition-all active:scale-95"
              title="Test chime sound and browser alert"
            >
              <Play className="w-3 h-3 text-amber-400 fill-amber-400" />
              <span>{testTriggered ? 'Chiming...' : 'Test'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
