import React from 'react';
import { Compass, Sunrise, Sunset, Clock, Sun } from 'lucide-react';
import { SolarPosition, SolarTimes, formatDuration } from '../utils/solarMath';
import { DynamicTheme } from '../utils/themeEngine';

interface SolarArcProps {
  solarPosition: SolarPosition;
  solarTimes: SolarTimes;
  theme: DynamicTheme;
  currentTime: Date;
}

export const SolarArc: React.FC<SolarArcProps> = ({
  solarPosition,
  solarTimes,
  theme,
  currentTime,
}) => {
  // SVG Canvas dimensions
  const width = 640;
  const height = 300;
  const horizonY = 200;
  const cx = width / 2;
  const rx = 260; // Horizontal radius
  const ry = 140; // Daytime vertical radius

  // Map elevation (-90 to +90) and time-of-day progression into the arc coordinates
  // Calculate day progress: from solar midnight to solar midnight (0 to 1)
  const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes() + currentTime.getSeconds() / 60;
  
  // Calculate x and y for the sun along the visual arc
  // When elevation > 0: sun is above horizon
  // Normalize elevation: -90 to +90
  const elevClamped = Math.max(-90, Math.min(90, solarPosition.elevation));
  
  // Calculate horizontal position based on azimuth or day fraction
  // Azimuth: 0=N, 90=E, 180=S, 270=W
  // Sunrise occurs roughly in East (x ~ 60), Noon at South (x ~ 320), Sunset roughly in West (x ~ 580)
  let sunX = cx;
  let sunY = horizonY;

  // Fraction of day from sunrise to sunset
  if (solarTimes.sunrise && solarTimes.sunset) {
    const riseMs = solarTimes.sunrise.getTime();
    const setMs = solarTimes.sunset.getTime();
    const nowMs = currentTime.getTime();

    if (nowMs >= riseMs && nowMs <= setMs) {
      // Daytime: smooth progress between sunrise and sunset
      const progress = (nowMs - riseMs) / (setMs - riseMs);
      const angle = Math.PI * (1 - progress); // PI to 0
      sunX = cx + rx * Math.cos(angle);
      // Height proportional to elevation vs maxSolarElevation
      const maxElev = Math.max(10, solarTimes.maxSolarElevation);
      const elevRatio = Math.max(0, elevClamped / maxElev);
      sunY = horizonY - ry * Math.sin(Math.PI * progress) * (0.3 + 0.7 * elevRatio);
    } else {
      // Nighttime: sun below horizon
      let nightProgress = 0;
      if (nowMs > setMs) {
        // Evening to midnight
        const totalNightMs = 24 * 3600000 - (setMs - riseMs);
        nightProgress = (nowMs - setMs) / totalNightMs;
      } else {
        // Midnight to morning
        const totalNightMs = 24 * 3600000 - (setMs - riseMs);
        const sinceSetMs = nowMs + (24 * 3600000 - setMs);
        nightProgress = sinceSetMs / totalNightMs;
      }
      const angle = Math.PI * (1 + nightProgress);
      sunX = cx + rx * Math.cos(angle);
      sunY = horizonY + 50 * Math.sin(Math.PI * nightProgress);
    }
  } else {
    // Fallback if polar day/night
    const angle = (currentMinutes / 1440) * Math.PI * 2;
    sunX = cx + rx * Math.cos(angle - Math.PI / 2);
    sunY = horizonY - (elevClamped / 90) * (ry * 0.8);
  }

  // Compass direction label for azimuth
  const getAzimuthCardinal = (deg: number) => {
    const cardinals = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const idx = Math.round(deg / 45) % 8;
    return `${deg.toFixed(1)}° ${cardinals[idx]}`;
  };

  return (
    <div
      className="w-full rounded-3xl p-5 md:p-6 backdrop-blur-xl border transition-all shadow-lg"
      style={{
        backgroundColor: theme.surface,
        borderColor: theme.cardBorder,
        color: theme.textPrimary,
      }}
    >
      {/* Top Title & Live Status */}
      <div className="flex items-center justify-between gap-4 mb-3">
        <div className="flex items-center gap-2">
          <Sun className="w-4 h-4" style={{ color: theme.primary }} />
          <h2 className="text-sm font-semibold tracking-wide">Solar Arc & Trajectory</h2>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono-numbers opacity-80">
          <span className="hidden sm:inline">Altitude:</span>
          <span className="font-bold text-sm" style={{ color: theme.primary }}>
            {solarPosition.elevation >= 0 ? `+${solarPosition.elevation.toFixed(1)}°` : `${solarPosition.elevation.toFixed(1)}°`}
          </span>
        </div>
      </div>

      {/* SVG Arc Celestial Dome */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto overflow-visible"
        >
          <defs>
            {/* Daytime Sky Fill Gradient */}
            <linearGradient id="domeDayGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={theme.primary} stopOpacity="0.16" />
              <stop offset="80%" stopColor={theme.primary} stopOpacity="0.04" />
              <stop offset="100%" stopColor={theme.primary} stopOpacity="0" />
            </linearGradient>

            {/* Night Sky Fill Gradient */}
            <linearGradient id="domeNightGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#000000" stopOpacity="0" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.25" />
            </linearGradient>

            {/* Golden Hour Horizon Band Gradient */}
            <linearGradient id="goldenBand" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.3" />
              <stop offset="50%" stopColor="#fbbf24" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.3" />
            </linearGradient>

            {/* Sun Glow Filter */}
            <filter id="sunGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Upper Celestial Dome Fill */}
          <path
            d={`M ${cx - rx} ${horizonY} A ${rx} ${ry} 0 0 1 ${cx + rx} ${horizonY} Z`}
            fill="url(#domeDayGrad)"
          />

          {/* Lower Ground / Night Fill */}
          <path
            d={`M ${cx - rx} ${horizonY} A ${rx} 60 0 0 0 ${cx + rx} ${horizonY} Z`}
            fill="url(#domeNightGrad)"
          />

          {/* Golden Hour Band Highlight along horizon (-4° to +6°) */}
          <rect
            x={cx - rx - 10}
            y={horizonY - 14}
            width={rx * 2 + 20}
            height={26}
            rx={4}
            fill="url(#goldenBand)"
            opacity={0.4}
          />

          {/* Daytime Sun Trajectory Arc (Dotted or solid) */}
          <path
            d={`M ${cx - rx} ${horizonY} A ${rx} ${ry} 0 0 1 ${cx + rx} ${horizonY}`}
            fill="none"
            stroke={theme.primary}
            strokeWidth="2.5"
            strokeDasharray="4 6"
            opacity="0.65"
          />

          {/* Night Return Arc */}
          <path
            d={`M ${cx - rx} ${horizonY} A ${rx} 60 0 0 0 ${cx + rx} ${horizonY}`}
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeDasharray="2 6"
            opacity="0.25"
          />

          {/* Horizon Line */}
          <line
            x1="30"
            y1={horizonY}
            x2={width - 30}
            y2={horizonY}
            stroke="currentColor"
            strokeWidth="1.5"
            opacity="0.3"
          />

          {/* Horizon Center Zenith Line Marker */}
          <line
            x1={cx}
            y1={horizonY - ry}
            x2={cx}
            y2={horizonY}
            stroke="currentColor"
            strokeWidth="1"
            strokeDasharray="3 4"
            opacity="0.18"
          />

          {/* Solar Noon Apex Marker */}
          <circle
            cx={cx}
            y={horizonY - ry}
            r="3"
            fill={theme.primary}
            opacity="0.8"
          />
          <text
            x={cx}
            y={horizonY - ry - 8}
            textAnchor="middle"
            fill="currentColor"
            fontSize="10"
            className="font-mono-numbers"
            opacity="0.6"
          >
            Solar Noon ({solarTimes.maxSolarElevation.toFixed(0)}°)
          </text>

          {/* Horizon Labels (East, Horizon, West) */}
          <text
            x={cx - rx}
            y={horizonY + 18}
            textAnchor="middle"
            fill="currentColor"
            fontSize="11"
            fontWeight="600"
            opacity="0.75"
          >
            E (Dawn)
          </text>
          <text
            x={cx}
            y={horizonY + 18}
            textAnchor="middle"
            fill="currentColor"
            fontSize="10"
            opacity="0.5"
          >
            Horizon 0°
          </text>
          <text
            x={cx + rx}
            y={horizonY + 18}
            textAnchor="middle"
            fill="currentColor"
            fontSize="11"
            fontWeight="600"
            opacity="0.75"
          >
            W (Dusk)
          </text>

          {/* Vertical drop ray from Sun to horizon */}
          <line
            x1={sunX}
            y1={sunY}
            x2={sunX}
            y2={horizonY}
            stroke={theme.primary}
            strokeWidth="1.5"
            strokeDasharray="2 3"
            opacity="0.5"
          />

          {/* Sun Glow Outer Halo */}
          <circle
            cx={sunX}
            y={sunY}
            r="22"
            fill={theme.sunGlowColor}
            opacity="0.8"
          />

          {/* Animated Sun Orb */}
          <circle
            cx={sunX}
            y={sunY}
            r="11"
            fill={solarPosition.elevation >= 0 ? '#fbbf24' : '#60a5fa'}
            stroke="#ffffff"
            strokeWidth="2.5"
            filter="url(#sunGlow)"
          />
        </svg>
      </div>

      {/* Bottom Telemetry Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-3 border-t" style={{ borderColor: theme.cardBorder }}>
        <div className="flex flex-col">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Compass className="w-3 h-3" /> Azimuth
          </span>
          <span className="text-sm font-semibold font-mono-numbers tracking-tight mt-0.5">
            {getAzimuthCardinal(solarPosition.azimuth)}
          </span>
        </div>

        <div className="flex flex-col">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Clock className="w-3 h-3" /> Daylight
          </span>
          <span className="text-sm font-semibold font-mono-numbers tracking-tight mt-0.5">
            {formatDuration(solarTimes.dayLengthMinutes)}
          </span>
        </div>

        <div className="flex flex-col">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Sunrise className="w-3 h-3 text-amber-400" /> Golden Dawn
          </span>
          <span className="text-sm font-semibold font-mono-numbers tracking-tight mt-0.5">
            {solarTimes.goldenHourDawnStart
              ? solarTimes.goldenHourDawnStart.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : 'N/A'}
          </span>
        </div>

        <div className="flex flex-col">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Sunset className="w-3 h-3 text-orange-400" /> Golden Dusk
          </span>
          <span className="text-sm font-semibold font-mono-numbers tracking-tight mt-0.5">
            {solarTimes.goldenHourDuskStart
              ? solarTimes.goldenHourDuskStart.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : 'N/A'}
          </span>
        </div>
      </div>
    </div>
  );
};
