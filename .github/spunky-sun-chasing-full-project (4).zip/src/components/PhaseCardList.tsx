import React, { useRef, useState, useEffect } from 'react';
import {
  Sunrise,
  Sunset,
  Sun,
  Moon,
  Sparkles,
  CloudSun,
  Eye,
  Compass,
  ChevronLeft,
  ChevronRight,
  Layers,
  LayoutGrid
} from 'lucide-react';
import { SolarTimes, formatSolarTime, SolarPhase } from '../utils/solarMath';
import { DynamicTheme } from '../utils/themeEngine';

interface PhaseCardListProps {
  solarTimes: SolarTimes;
  currentPhase: SolarPhase;
  currentTime: Date;
  theme: DynamicTheme;
  onSelectTime?: (time: Date) => void;
}

interface PhaseItem {
  id: string;
  name: string;
  subtext: string;
  angleRange: string;
  icon: React.ReactNode;
  startTime: Date | null;
  endTime: Date | null;
  isCurrent: boolean;
  accentColor: string;
  lightingNote: string;
}

export const PhaseCardList: React.FC<PhaseCardListProps> = ({
  solarTimes,
  currentPhase,
  currentTime,
  theme,
  onSelectTime,
}) => {
  const [viewMode, setViewMode] = useState<'carousel' | 'grid'>('carousel');
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const nowMs = currentTime.getTime();

  const isBetween = (start: Date | null, end: Date | null) => {
    if (!start || !end) return false;
    return nowMs >= start.getTime() && nowMs <= end.getTime();
  };

  const getDurationText = (start: Date | null, end: Date | null) => {
    if (!start || !end) return '--';
    const mins = Math.round((end.getTime() - start.getTime()) / 60000);
    if (mins < 60) return `${mins}m`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m}m`;
  };

  // Full chronological astronomical phases including Nautical Twilight
  const phases: PhaseItem[] = [
    {
      id: 'nautical_dawn',
      name: 'Dawn Nautical Twilight',
      subtext: 'Faint horizon visible at sea; bright navigational stars visible',
      angleRange: '-12° to -6°',
      icon: <Compass className="w-5 h-5 text-cyan-400" />,
      startTime: solarTimes.nauticalDawn,
      endTime: solarTimes.blueHourDawnStart || solarTimes.civilDawn,
      isCurrent:
        isBetween(solarTimes.nauticalDawn, solarTimes.blueHourDawnStart || solarTimes.civilDawn) ||
        (currentPhase === 'nautical_twilight' && nowMs < (solarTimes.solarNoon?.getTime() ?? 0)),
      accentColor: '#38bdf8',
      lightingNote: 'Deep cobalt sky. Sea navigators can take stellar fixes; ideal for landscape silhouettes against stars.',
    },
    {
      id: 'blue_dawn',
      name: 'Dawn Blue Hour',
      subtext: 'Atmospheric indigo glow before sunrise',
      angleRange: '-6° to -4°',
      icon: <Eye className="w-5 h-5 text-indigo-400" />,
      startTime: solarTimes.blueHourDawnStart,
      endTime: solarTimes.blueHourDawnEnd,
      isCurrent:
        isBetween(solarTimes.blueHourDawnStart, solarTimes.blueHourDawnEnd) ||
        currentPhase === 'blue_hour_dawn',
      accentColor: '#818cf8',
      lightingNote: 'Cool 9000K–10000K tones, high atmospheric contrast, ideal for illuminated architecture.',
    },
    {
      id: 'golden_dawn',
      name: 'Morning Golden Hour',
      subtext: 'First warm directional rays of the day',
      angleRange: '-4° to +6°',
      icon: <Sparkles className="w-5 h-5 text-amber-400" />,
      startTime: solarTimes.goldenHourDawnStart,
      endTime: solarTimes.goldenHourDawnEnd,
      isCurrent:
        isBetween(solarTimes.goldenHourDawnStart, solarTimes.goldenHourDawnEnd) ||
        currentPhase === 'golden_hour_dawn',
      accentColor: '#fbbf24',
      lightingNote: 'Warm 3000K–3500K golden light, long soft shadows, minimal atmospheric haze.',
    },
    {
      id: 'sunrise',
      name: 'Official Sunrise',
      subtext: 'Upper edge of solar disc appears on horizon',
      angleRange: '0° horizon',
      icon: <Sunrise className="w-5 h-5 text-orange-400" />,
      startTime: solarTimes.sunrise,
      endTime: solarTimes.sunrise ? new Date(solarTimes.sunrise.getTime() + 15 * 60000) : null,
      isCurrent: solarTimes.sunrise
        ? Math.abs(nowMs - solarTimes.sunrise.getTime()) <= 10 * 60000
        : false,
      accentColor: '#f97316',
      lightingNote: 'Direct radiant horizon illumination with rapid color shift.',
    },
    {
      id: 'solar_noon',
      name: 'Solar Noon & Zenith',
      subtext: `Sun reaches maximum elevation (${solarTimes.maxSolarElevation.toFixed(1)}°)`,
      angleRange: `Max +${solarTimes.maxSolarElevation.toFixed(0)}°`,
      icon: <Sun className="w-5 h-5 text-amber-300" />,
      startTime: solarTimes.solarNoon,
      endTime: null,
      isCurrent: solarTimes.solarNoon
        ? Math.abs(nowMs - solarTimes.solarNoon.getTime()) <= 30 * 60000
        : false,
      accentColor: '#38bdf8',
      lightingNote: 'Bright 5500K–6500K overhead light with short shadows and high dynamic range.',
    },
    {
      id: 'golden_dusk',
      name: 'Evening Golden Hour',
      subtext: 'Low-angle golden lighting before sunset',
      angleRange: '+6° to -4°',
      icon: <Sparkles className="w-5 h-5 text-amber-500" />,
      startTime: solarTimes.goldenHourDuskStart,
      endTime: solarTimes.goldenHourDuskEnd,
      isCurrent:
        isBetween(solarTimes.goldenHourDuskStart, solarTimes.goldenHourDuskEnd) ||
        currentPhase === 'golden_hour_dusk',
      accentColor: '#f59e0b',
      lightingNote: 'Golden amber glow with dramatic elongated shadows. Prime portrait window.',
    },
    {
      id: 'sunset',
      name: 'Official Sunset',
      subtext: 'Solar disc fully vanishes below the horizon',
      angleRange: '0° horizon',
      icon: <Sunset className="w-5 h-5 text-red-400" />,
      startTime: solarTimes.sunset,
      endTime: solarTimes.sunset ? new Date(solarTimes.sunset.getTime() + 15 * 60000) : null,
      isCurrent: solarTimes.sunset
        ? Math.abs(nowMs - solarTimes.sunset.getTime()) <= 10 * 60000
        : false,
      accentColor: '#ef4444',
      lightingNote: 'Horizon gradient transitions from red-orange into twilight magenta.',
    },
    {
      id: 'blue_dusk',
      name: 'Dusk Blue Hour',
      subtext: 'Deep sapphire twilight after sundown',
      angleRange: '-4° to -6°',
      icon: <Eye className="w-5 h-5 text-blue-400" />,
      startTime: solarTimes.blueHourDuskStart,
      endTime: solarTimes.blueHourDuskEnd,
      isCurrent:
        isBetween(solarTimes.blueHourDuskStart, solarTimes.blueHourDuskEnd) ||
        currentPhase === 'blue_hour_dusk',
      accentColor: '#60a5fa',
      lightingNote: 'Deep blue-indigo sky. Perfectly balances with warm interior city artificial lights.',
    },
    {
      id: 'nautical_dusk',
      name: 'Dusk Nautical Twilight',
      subtext: 'Sea horizon remains visible against the darkening sky',
      angleRange: '-6° to -12°',
      icon: <Compass className="w-5 h-5 text-teal-400" />,
      startTime: solarTimes.blueHourDuskEnd || solarTimes.civilDusk,
      endTime: solarTimes.nauticalDusk,
      isCurrent:
        isBetween(solarTimes.blueHourDuskEnd || solarTimes.civilDusk, solarTimes.nauticalDusk) ||
        (currentPhase === 'nautical_twilight' && nowMs >= (solarTimes.solarNoon?.getTime() ?? 0)),
      accentColor: '#2dd4bf',
      lightingNote: 'First-magnitude navigational stars and planets emerge; ideal transition into astrophotography.',
    },
    {
      id: 'night',
      name: 'Night & Astrophotography',
      subtext: 'Astronomical darkness begins',
      angleRange: '< -18°',
      icon: <Moon className="w-5 h-5 text-indigo-300" />,
      startTime: solarTimes.astronomicalDusk,
      endTime: solarTimes.astronomicalDawn,
      isCurrent: currentPhase === 'night' || currentPhase === 'astronomical_twilight',
      accentColor: '#a5b4fc',
      lightingNote: 'Zero solar interference. Pristine conditions for Milky Way and deep space objects.',
    },
  ];

  // Find index of current phase
  const currentIndex = phases.findIndex((p) => p.isCurrent);

  // Scroll to a specific card index
  const scrollToIndex = (index: number) => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const cards = container.children;
    if (cards[index]) {
      (cards[index] as HTMLElement).scrollIntoView({
        behavior: 'smooth',
        inline: 'center',
        block: 'nearest',
      });
      setActiveCardIndex(index);
    }
  };

  const handlePrev = () => {
    const nextIndex = Math.max(0, activeCardIndex - 1);
    scrollToIndex(nextIndex);
  };

  const handleNext = () => {
    const nextIndex = Math.min(phases.length - 1, activeCardIndex + 1);
    scrollToIndex(nextIndex);
  };

  const handleJumpToCurrent = () => {
    if (currentIndex >= 0) {
      scrollToIndex(currentIndex);
    }
  };

  // Update activeCardIndex on manual swipe scroll
  const handleScroll = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const scrollLeft = container.scrollLeft;
    const cardWidth = container.firstElementChild ? (container.firstElementChild as HTMLElement).offsetWidth + 12 : 300;
    const idx = Math.round(scrollLeft / cardWidth);
    if (idx >= 0 && idx < phases.length && idx !== activeCardIndex) {
      setActiveCardIndex(idx);
    }
  };

  // Auto-scroll to active phase on mount or when active phase changes
  useEffect(() => {
    if (currentIndex >= 0 && viewMode === 'carousel') {
      scrollToIndex(currentIndex);
    }
  }, [currentIndex, viewMode]);

  return (
    <div className="w-full flex flex-col gap-3">
      {/* Header controls: Title, active phase jump, swipe buttons & view toggle */}
      <div className="flex items-center justify-between px-1 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <CloudSun className="w-4 h-4" style={{ color: theme.primary }} />
          <h3 className="text-sm font-semibold tracking-wide">Solar Phases & Lighting Cards</h3>
          <span className="text-[10px] text-slate-400 hidden sm:inline">
            (Swipe left/right)
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Jump to active phase button */}
          {currentIndex >= 0 && (
            <button
              onClick={handleJumpToCurrent}
              className="px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 active:scale-95"
              style={{
                backgroundColor: `${theme.primary}20`,
                borderColor: `${theme.primary}50`,
                color: theme.primary,
              }}
              title="Jump to current active solar phase"
            >
              <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: theme.primary }} />
              <span>Current: {phases[currentIndex]?.name.split(' ')[0]}</span>
            </button>
          )}

          {/* Toggle between Swipe Deck and Grid */}
          <button
            onClick={() => setViewMode(viewMode === 'carousel' ? 'grid' : 'carousel')}
            className="p-1.5 rounded-xl border transition-colors cursor-pointer text-slate-300 hover:text-white"
            style={{
              backgroundColor: theme.surfaceContainer,
              borderColor: theme.cardBorder,
            }}
            title={viewMode === 'carousel' ? 'Switch to Grid View' : 'Switch to Swipe Carousel'}
          >
            {viewMode === 'carousel' ? <LayoutGrid className="w-3.5 h-3.5" /> : <Layers className="w-3.5 h-3.5" />}
          </button>

          {/* Carousel Left / Right Arrows */}
          {viewMode === 'carousel' && (
            <div className="flex items-center gap-1 ml-1">
              <button
                onClick={handlePrev}
                disabled={activeCardIndex <= 0}
                className="w-7 h-7 rounded-full border flex items-center justify-center transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10"
                style={{
                  backgroundColor: theme.surfaceContainer,
                  borderColor: theme.cardBorder,
                  color: theme.textPrimary,
                }}
                aria-label="Previous card"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                disabled={activeCardIndex >= phases.length - 1}
                className="w-7 h-7 rounded-full border flex items-center justify-center transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white/10"
                style={{
                  backgroundColor: theme.surfaceContainer,
                  borderColor: theme.cardBorder,
                  color: theme.textPrimary,
                }}
                aria-label="Next card"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* SWIPEABLE CARD CAROUSEL VIEW (Default) */}
      {viewMode === 'carousel' ? (
        <div className="relative w-full">
          {/* Scrollable Container with Native Scroll Snap */}
          <div
            ref={scrollContainerRef}
            onScroll={handleScroll}
            className="flex gap-3 overflow-x-auto snap-x snap-mandatory scrollbar-none py-1.5 px-0.5 -mx-1"
            style={{
              scrollSnapType: 'x mandatory',
              WebkitOverflowScrolling: 'touch',
              scrollbarWidth: 'none',
              msOverflowStyle: 'none',
            }}
          >
            {phases.map((phase, idx) => (
              <div
                key={phase.id}
                onClick={() => {
                  scrollToIndex(idx);
                  if (phase.startTime && onSelectTime) {
                    onSelectTime(phase.startTime);
                  }
                }}
                className={`w-[85vw] max-w-[320px] sm:w-[310px] shrink-0 snap-center rounded-[28px] p-4.5 backdrop-blur-xl border transition-all duration-300 relative flex flex-col justify-between cursor-pointer select-none shadow-lg ${
                  phase.isCurrent
                    ? 'ring-2 ring-amber-400 shadow-amber-500/10 scale-[1.01]'
                    : 'hover:border-white/20'
                }`}
                style={{
                  backgroundColor: phase.isCurrent ? theme.surfaceContainerHigh : theme.surface,
                  borderColor: phase.isCurrent ? phase.accentColor : theme.cardBorder,
                  color: theme.textPrimary,
                }}
              >
                {/* Top row: Icon + Angle + Active Badge */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-sm transition-transform"
                      style={{
                        backgroundColor: `${phase.accentColor}25`,
                      }}
                    >
                      {phase.icon}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] font-mono-numbers px-2 py-0.5 rounded-full bg-white/5 border border-white/5 text-slate-400">
                        {phase.angleRange}
                      </span>
                      {phase.isCurrent && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500 text-slate-950 uppercase tracking-wider animate-pulse">
                          Active
                        </span>
                      )}
                    </div>
                  </div>

                  <h4 className="text-sm font-bold tracking-tight font-display text-white">
                    {phase.name}
                  </h4>
                  <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                    {phase.subtext}
                  </p>
                </div>

                {/* Bottom section: Window, Duration, Notes */}
                <div className="mt-4 pt-3 border-t border-white/10 flex flex-col gap-1.5">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs text-slate-400">Time Window</span>
                    <span className="text-sm font-bold font-mono-numbers" style={{ color: phase.accentColor }}>
                      {formatSolarTime(phase.startTime)}
                      {phase.endTime ? ` – ${formatSolarTime(phase.endTime)}` : ''}
                    </span>
                  </div>

                  {phase.startTime && phase.endTime && (
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>Duration</span>
                      <span className="font-mono-numbers text-slate-300">
                        {getDurationText(phase.startTime, phase.endTime)}
                      </span>
                    </div>
                  )}

                  <p className="text-[11px] text-slate-300/90 leading-relaxed mt-1 line-clamp-2">
                    {phase.lightingNote}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination Indicators / Dots */}
          <div className="flex items-center justify-center gap-1.5 pt-3">
            {phases.map((p, i) => (
              <button
                key={p.id}
                onClick={() => scrollToIndex(i)}
                className={`transition-all duration-300 rounded-full cursor-pointer ${
                  i === activeCardIndex
                    ? 'w-6 h-2 bg-amber-400'
                    : p.isCurrent
                    ? 'w-2 h-2 bg-amber-400/80 ring-2 ring-amber-400/40'
                    : 'w-2 h-2 bg-white/20 hover:bg-white/40'
                }`}
                aria-label={`Go to ${p.name}`}
              />
            ))}
          </div>
        </div>
      ) : (
        /* EXPANDED GRID VIEW (When toggled) */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {phases.map((phase) => (
            <div
              key={phase.id}
              onClick={() => {
                if (phase.startTime && onSelectTime) {
                  onSelectTime(phase.startTime);
                }
              }}
              className={`rounded-[28px] p-4.5 backdrop-blur-xl border transition-all relative flex flex-col justify-between cursor-pointer ${
                phase.isCurrent ? 'ring-2 ring-amber-400 shadow-md scale-[1.01]' : 'hover:border-white/20'
              }`}
              style={{
                backgroundColor: phase.isCurrent ? theme.surfaceContainerHigh : theme.surface,
                borderColor: phase.isCurrent ? phase.accentColor : theme.cardBorder,
                color: theme.textPrimary,
              }}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div
                    className="w-9 h-9 rounded-2xl flex items-center justify-center shrink-0"
                    style={{
                      backgroundColor: `${phase.accentColor}25`,
                    }}
                  >
                    {phase.icon}
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono-numbers text-slate-400">
                      {phase.angleRange}
                    </span>
                    {phase.isCurrent && (
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500 text-slate-950 uppercase tracking-wider">
                        Active
                      </span>
                    )}
                  </div>
                </div>

                <h4 className="text-sm font-bold tracking-tight font-display text-white">
                  {phase.name}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                  {phase.subtext}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 flex flex-col gap-1.5">
                <div className="flex items-baseline justify-between">
                  <span className="text-xs text-slate-400">Window</span>
                  <span className="text-sm font-bold font-mono-numbers" style={{ color: phase.accentColor }}>
                    {formatSolarTime(phase.startTime)}
                    {phase.endTime ? ` – ${formatSolarTime(phase.endTime)}` : ''}
                  </span>
                </div>

                {phase.startTime && phase.endTime && (
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Duration</span>
                    <span className="font-mono-numbers text-slate-300">
                      {getDurationText(phase.startTime, phase.endTime)}
                    </span>
                  </div>
                )}

                <p className="text-[11px] text-slate-300/90 leading-tight mt-1 line-clamp-2">
                  {phase.lightingNote}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
