import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Sparkles,
  Sunrise,
  Sunset,
  Sun,
  Moon,
  Layers,
  Sliders,
  Check,
  Maximize2,
  X,
  Play,
  RotateCcw
} from 'lucide-react';
import { SolarTimes, SolarPosition, SolarPhaseInfo, formatSolarTime } from '../utils/solarMath';
import { LocationData } from '../utils/storage';
import { DynamicTheme } from '../utils/themeEngine';

interface OneUIWidgetProps {
  solarTimes: SolarTimes;
  solarPosition: SolarPosition;
  currentPhaseInfo: SolarPhaseInfo;
  location: LocationData;
  currentTime: Date;
  theme: DynamicTheme;
  onClose?: () => void;
}

export type WidgetSize = '4x2' | '2x2' | '4x1' | '2x1';
export type WidgetStyle = 'dynamic_sky' | 'glass' | 'amoled';

export const OneUIWidget: React.FC<OneUIWidgetProps> = ({
  solarTimes,
  solarPosition,
  currentPhaseInfo,
  location,
  currentTime,
  theme,
  onClose,
}) => {
  const [size, setSize] = useState<WidgetSize>('4x2');
  const [styleMode, setStyleMode] = useState<WidgetStyle>('dynamic_sky');
  const [pipActive, setPipActive] = useState(false);
  const [pipError, setPipError] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Time remaining to next golden hour
  const nowMs = currentTime.getTime();
  const mornStart = solarTimes.goldenHourDawnStart?.getTime() ?? 0;
  const mornEnd = solarTimes.goldenHourDawnEnd?.getTime() ?? 0;
  const eveStart = solarTimes.goldenHourDuskStart?.getTime() ?? 0;
  const eveEnd = solarTimes.goldenHourDuskEnd?.getTime() ?? 0;

  const isMorningGolden = nowMs >= mornStart && nowMs <= mornEnd;
  const isEveningGolden = nowMs >= eveStart && nowMs <= eveEnd;
  const isGoldenActive = isMorningGolden || isEveningGolden;

  let goldenCountdown = '';
  if (isGoldenActive) {
    const endTarget = isMorningGolden ? mornEnd : eveEnd;
    const diffSec = Math.max(0, Math.floor((endTarget - nowMs) / 1000));
    goldenCountdown = `Ends in ${Math.floor(diffSec / 60)}m`;
  } else if (solarTimes.goldenHourDuskStart && nowMs < eveStart) {
    const diffSec = Math.floor((eveStart - nowMs) / 1000);
    const h = Math.floor(diffSec / 3600);
    const m = Math.floor((diffSec % 3600) / 60);
    goldenCountdown = `In ${h}h ${m}m`;
  } else if (solarTimes.goldenHourDawnStart && nowMs < mornStart) {
    const diffSec = Math.floor((mornStart - nowMs) / 1000);
    const h = Math.floor(diffSec / 3600);
    const m = Math.floor((diffSec % 3600) / 60);
    goldenCountdown = `In ${h}h ${m}m`;
  } else {
    goldenCountdown = 'Tomorrow';
  }

  // Calculate dynamic time-of-day widget background and sun colors
  const widgetColors = useMemo(() => {
    const elev = solarPosition.elevation;

    if (styleMode === 'amoled') {
      return {
        bg: 'linear-gradient(145deg, #07090e 0%, #0d121c 100%)',
        border: 'rgba(255, 255, 255, 0.08)',
        accent: isGoldenActive ? '#f59e0b' : '#38bdf8',
        sunColor: elev >= 0 ? '#fbbf24' : '#60a5fa',
        glow: isGoldenActive ? 'rgba(245, 158, 11, 0.35)' : 'rgba(56, 189, 248, 0.2)',
      };
    }

    if (styleMode === 'glass') {
      return {
        bg: 'rgba(15, 23, 42, 0.65)',
        border: 'rgba(255, 255, 255, 0.16)',
        accent: isGoldenActive ? '#f59e0b' : theme.primary,
        sunColor: elev >= 0 ? '#fbbf24' : '#93c5fd',
        glow: isGoldenActive ? 'rgba(245, 158, 11, 0.4)' : 'rgba(147, 197, 253, 0.25)',
      };
    }

    // Dynamic Sky Mode (morphs precisely with time of day)
    if (elev < -18) {
      // Deep Night
      return {
        bg: 'linear-gradient(135deg, #070b14 0%, #0f172a 60%, #1e1b4b 100%)',
        border: 'rgba(148, 163, 184, 0.15)',
        accent: '#93c5fd',
        sunColor: '#a5b4fc',
        glow: 'rgba(147, 197, 253, 0.15)',
      };
    } else if (elev < -6) {
      // Twilight / Nautical
      return {
        bg: 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #311b42 100%)',
        border: 'rgba(192, 132, 252, 0.2)',
        accent: '#c084fc',
        sunColor: '#e879f9',
        glow: 'rgba(192, 132, 252, 0.3)',
      };
    } else if (elev < -4) {
      // Blue Hour
      return {
        bg: 'linear-gradient(135deg, #101c38 0%, #1e3563 55%, #4a2d59 100%)',
        border: 'rgba(96, 165, 250, 0.25)',
        accent: '#60a5fa',
        sunColor: '#93c5fd',
        glow: 'rgba(96, 165, 250, 0.45)',
      };
    } else if (elev < 6) {
      // Golden Hour
      return {
        bg: 'linear-gradient(135deg, #2a1b24 0%, #572922 45%, #92400e 100%)',
        border: 'rgba(251, 191, 36, 0.35)',
        accent: '#fbbf24',
        sunColor: '#fbbf24',
        glow: 'rgba(245, 158, 11, 0.65)',
      };
    } else {
      // Full Daylight
      return {
        bg: 'linear-gradient(135deg, #0c2d48 0%, #145da0 55%, #2e8bc0 100%)',
        border: 'rgba(56, 189, 248, 0.25)',
        accent: '#38bdf8',
        sunColor: '#fef08a',
        glow: 'rgba(254, 240, 138, 0.55)',
      };
    }
  }, [solarPosition.elevation, isGoldenActive, styleMode, theme.primary]);

  // Dynamic Sun X & Y along the 4x2 mini arc
  const arcGeometry = useMemo(() => {
    const width = 360;
    const horizonY = 46;
    const rx = 150;
    const ry = 34;
    const cx = width / 2;

    const elev = Math.max(-90, Math.min(90, solarPosition.elevation));
    const maxElev = Math.max(15, solarTimes.maxSolarElevation);

    // X based on day fraction
    let sunX = cx;
    let sunY = horizonY;

    if (solarTimes.sunrise && solarTimes.sunset) {
      const rise = solarTimes.sunrise.getTime();
      const set = solarTimes.sunset.getTime();
      if (nowMs >= rise && nowMs <= set) {
        // Daytime
        const progress = (nowMs - rise) / (set - rise);
        const angle = Math.PI * (1 - progress);
        sunX = cx + rx * Math.cos(angle);
        const elevRatio = Math.max(0, elev / maxElev);
        sunY = horizonY - ry * Math.sin(Math.PI * progress) * (0.3 + 0.7 * elevRatio);
      } else {
        // Nighttime
        const totalNight = 24 * 3600000 - (set - rise);
        let nightProg = 0;
        if (nowMs > set) {
          nightProg = (nowMs - set) / totalNight;
        } else {
          nightProg = (nowMs + 24 * 3600000 - set) / totalNight;
        }
        const angle = Math.PI * (1 + nightProg);
        sunX = cx + rx * Math.cos(angle);
        sunY = horizonY + 12 * Math.sin(Math.PI * nightProg);
      }
    } else {
      sunX = cx;
      sunY = horizonY - (elev / 90) * ry;
    }

    return { cx, rx, ry, horizonY, sunX, sunY };
  }, [solarPosition.elevation, solarTimes, nowMs]);

  // Floating Picture-in-Picture (PiP) Widget Mode
  const launchFloatingPiP = async () => {
    setPipError(null);
    const canvas = canvasRef.current;
    if (!canvas) return;

    try {
      const stream = canvas.captureStream(10);
      let video = videoRef.current;
      if (!video) {
        video = document.createElement('video');
        video.muted = true;
        video.autoplay = true;
        video.playsInline = true;
        videoRef.current = video;
      }
      video.srcObject = stream;
      await video.play();

      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
        setPipActive(false);
      } else if (video.requestPictureInPicture) {
        await video.requestPictureInPicture();
        setPipActive(true);
        video.addEventListener('leavepictureinpicture', () => {
          setPipActive(false);
        });
      } else {
        setPipError('Picture-in-Picture floating mode is not supported on this browser.');
      }
    } catch (err: unknown) {
      console.warn('PiP error:', err);
      const msg = err instanceof Error ? err.message : 'Could not activate floating widget';
      setPipError(msg);
    }
  };

  // Render dynamic One UI 9 widget onto hidden canvas for floating PiP stream
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, 400, 200);

    // Dynamic gradient background matching solar phase
    const grad = ctx.createLinearGradient(0, 0, 400, 200);
    if (solarPosition.elevation < -12) {
      grad.addColorStop(0, '#070b14');
      grad.addColorStop(1, '#1e1b4b');
    } else if (solarPosition.elevation < 6) {
      grad.addColorStop(0, '#2a141b');
      grad.addColorStop(1, '#78350f');
    } else {
      grad.addColorStop(0, '#0c2d48');
      grad.addColorStop(1, '#1d4f8a');
    }

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(0, 0, 400, 200, 32);
    ctx.fill();

    // Border
    ctx.strokeStyle = widgetColors.border;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Title & Time
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px -apple-system, sans-serif';
    ctx.fillText('Spunky Sun', 24, 38);

    ctx.fillStyle = '#94a3b8';
    ctx.font = '13px -apple-system, sans-serif';
    ctx.fillText(location.name, 24, 58);

    // Dynamic Phase Tag
    ctx.fillStyle = widgetColors.accent;
    ctx.font = 'bold 12px -apple-system, sans-serif';
    ctx.fillText(
      isGoldenActive ? '● GOLDEN HOUR' : currentPhaseInfo.name.toUpperCase(),
      24,
      95
    );

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 22px -apple-system, sans-serif';
    ctx.fillText(goldenCountdown, 24, 125);

    // Sunrise / Sunset right column
    ctx.fillStyle = '#f97316';
    ctx.font = '12px -apple-system, sans-serif';
    ctx.fillText('↑ Sunrise', 260, 45);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px -apple-system, sans-serif';
    ctx.fillText(formatSolarTime(solarTimes.sunrise), 260, 68);

    ctx.fillStyle = '#ef4444';
    ctx.font = '12px -apple-system, sans-serif';
    ctx.fillText('↓ Sunset', 260, 105);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 16px -apple-system, sans-serif';
    ctx.fillText(formatSolarTime(solarTimes.sunset), 260, 128);

    // Bottom telemetry bar
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.beginPath();
    ctx.roundRect(24, 150, 352, 34, 17);
    ctx.fill();

    ctx.fillStyle = '#cbd5e1';
    ctx.font = '12px -apple-system, sans-serif';
    ctx.fillText(currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 36, 172);

    ctx.fillStyle = widgetColors.sunColor;
    ctx.font = 'bold 13px -apple-system, monospace';
    const altText = `${solarPosition.elevation >= 0 ? '+' : ''}${solarPosition.elevation.toFixed(1)}° alt`;
    ctx.fillText(altText, 305, 172);
  }, [solarTimes, solarPosition, currentPhaseInfo, location, widgetColors, goldenCountdown, isGoldenActive, currentTime]);

  return (
    <div className="w-full flex flex-col gap-5">
      {/* Hidden canvas for PiP streaming */}
      <canvas ref={canvasRef} width={400} height={200} className="hidden" />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div
            className="w-9 h-9 rounded-2xl flex items-center justify-center shadow-sm"
            style={{ backgroundColor: theme.primary, color: theme.onPrimary }}
          >
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold tracking-tight font-display">
              Samsung One UI 9 Widget Studio
            </h2>
            <p className="text-xs text-slate-400">
              Adapts dynamically as the day passes · One UI 9 squircle geometry & floating PiP
            </p>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer self-end sm:self-auto"
            aria-label="Close widget view"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Controls Bar: Size & Style Selectors */}
      <div
        className="p-3.5 rounded-2xl border flex flex-wrap items-center justify-between gap-3 backdrop-blur-xl"
        style={{
          backgroundColor: theme.surfaceContainer,
          borderColor: theme.cardBorder,
        }}
      >
        {/* Size Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-semibold text-slate-400 mr-1 flex items-center gap-1">
            <Sliders className="w-3.5 h-3.5" /> Size:
          </span>
          {(['4x2', '2x2', '4x1', '2x1'] as WidgetSize[]).map((s) => (
            <button
              key={s}
              onClick={() => setSize(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                size === s
                  ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-sm'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Style Selector */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-semibold text-slate-400 mr-1">Style:</span>
          {(
            [
              { id: 'dynamic_sky', label: 'Dynamic Sky' },
              { id: 'glass', label: 'Frosted Glass' },
              { id: 'amoled', label: 'AMOLED Black' },
            ] as { id: WidgetStyle; label: string }[]
          ).map((st) => (
            <button
              key={st.id}
              onClick={() => setStyleMode(st.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer border ${
                styleMode === st.id
                  ? 'bg-amber-500 text-slate-950 font-bold border-amber-400'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>

        {/* Floating PiP Trigger Button */}
        <button
          onClick={launchFloatingPiP}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-sm active:scale-95 border"
          style={{
            backgroundColor: pipActive ? '#10b981' : theme.primary,
            color: pipActive ? '#ffffff' : theme.onPrimary,
            borderColor: theme.cardBorder,
          }}
          title="Float this widget over your phone home screen using Picture-in-Picture"
        >
          {pipActive ? <Check className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          <span>{pipActive ? 'Floating Active' : 'Float on Screen (PiP)'}</span>
        </button>
      </div>

      {pipError && (
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          {pipError}
        </div>
      )}

      {/* Galaxy One UI 9 Home Screen Preview Stage */}
      <div className="relative rounded-[36px] p-6 sm:p-10 border border-white/10 overflow-hidden shadow-2xl flex flex-col items-center justify-center bg-gradient-to-b from-slate-950 via-slate-900 to-black min-h-[380px]">
        {/* Subtle Samsung Galaxy wallpaper gradient backdrop */}
        <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_20%_30%,#3b82f6_0%,transparent_50%),radial-gradient(circle_at_80%_70%,#f59e0b_0%,transparent_50%)] pointer-events-none" />

        {/* One UI Top Status Bar Simulator */}
        <div className="w-full max-w-lg flex items-center justify-between text-[11px] font-semibold text-white/60 tracking-wider mb-6 px-4">
          <span>{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <div className="flex items-center gap-1.5 text-[10px]">
            <span>5G</span>
            <span>·</span>
            <span>100%</span>
          </div>
        </div>

        {/* ---------------- WIDGET 4x2 MASTER SOLAR HUB ---------------- */}
        {size === '4x2' && (
          <div
            className="w-full max-w-lg rounded-[32px] p-6 border transition-all duration-700 shadow-2xl relative overflow-hidden backdrop-blur-2xl"
            style={{
              background: widgetColors.bg,
              borderColor: widgetColors.border,
            }}
          >
            {/* Ambient dynamic sun glow in the corner */}
            <div
              className="absolute -right-8 -top-8 w-36 h-36 rounded-full pointer-events-none blur-3xl opacity-40 transition-all duration-700"
              style={{ backgroundColor: widgetColors.accent }}
            />

            {/* Top row */}
            <div className="flex items-center justify-between mb-3 relative z-10">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-2xl flex items-center justify-center transition-colors duration-500 shadow-sm"
                  style={{ backgroundColor: `${widgetColors.accent}25` }}
                >
                  {solarPosition.elevation >= 0 ? (
                    <Sun className="w-5 h-5" style={{ color: widgetColors.sunColor }} />
                  ) : (
                    <Moon className="w-5 h-5 text-indigo-300" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-tight text-white font-display">Spunky Sun</h3>
                  <p className="text-[11px] text-slate-300 truncate max-w-[150px]">{location.name}</p>
                </div>
              </div>

              {/* Status pill shifting with the day */}
              <div
                className="flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-semibold transition-all duration-500 shadow-sm"
                style={{
                  backgroundColor: `${widgetColors.accent}20`,
                  borderColor: `${widgetColors.accent}40`,
                  color: widgetColors.accent,
                }}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isGoldenActive ? 'Golden Hour' : currentPhaseInfo.name}</span>
              </div>
            </div>

            {/* Middle: Live Solar Trajectory Arc that shifts as day passes */}
            <div className="relative w-full h-18 my-2 select-none">
              <svg viewBox="0 0 360 65" className="w-full h-full overflow-visible">
                {/* Daytime arc */}
                <path
                  d="M 30 46 A 150 34 0 0 1 330 46"
                  fill="none"
                  stroke={widgetColors.accent}
                  strokeWidth="2"
                  strokeDasharray="4 4"
                  opacity="0.5"
                />
                {/* Night return */}
                <path
                  d="M 30 46 A 150 14 0 0 0 330 46"
                  fill="none"
                  stroke="rgba(255, 255, 255, 0.2)"
                  strokeWidth="1.5"
                  strokeDasharray="2 4"
                  opacity="0.3"
                />
                {/* Horizon line */}
                <line x1="20" y1="46" x2="340" y2="46" stroke="rgba(255, 255, 255, 0.25)" strokeWidth="1" />
                
                {/* Labels */}
                <text x="30" y="59" fill="rgba(255,255,255,0.6)" fontSize="9" fontWeight="600">E</text>
                <text x="330" y="59" fill="rgba(255,255,255,0.6)" fontSize="9" fontWeight="600" textAnchor="end">W</text>

                {/* Sun vertical ray */}
                <line
                  x1={arcGeometry.sunX}
                  y1={arcGeometry.sunY}
                  x2={arcGeometry.sunX}
                  y2={arcGeometry.horizonY}
                  stroke={widgetColors.accent}
                  strokeWidth="1.5"
                  strokeDasharray="2 2"
                  opacity="0.5"
                />

                {/* Sun Glow */}
                <circle
                  cx={arcGeometry.sunX}
                  cy={arcGeometry.sunY}
                  r="14"
                  fill={widgetColors.glow}
                />

                {/* Animated Sun Orb */}
                <circle
                  cx={arcGeometry.sunX}
                  cy={arcGeometry.sunY}
                  r="7"
                  fill={widgetColors.sunColor}
                  stroke="#ffffff"
                  strokeWidth="2"
                />
              </svg>
            </div>

            {/* Bottom: Metrics grid */}
            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/10 text-center">
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-300 flex items-center gap-1">
                  <Sunrise className="w-3 h-3 text-orange-400" /> Sunrise
                </span>
                <span className="text-sm font-bold text-white font-mono-numbers mt-0.5">
                  {formatSolarTime(solarTimes.sunrise)}
                </span>
              </div>

              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" /> Golden Alert
                </span>
                <span className="text-sm font-bold font-mono-numbers mt-0.5" style={{ color: widgetColors.accent }}>
                  {goldenCountdown}
                </span>
              </div>

              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-300 flex items-center gap-1">
                  <Sunset className="w-3 h-3 text-rose-400" /> Sunset
                </span>
                <span className="text-sm font-bold text-white font-mono-numbers mt-0.5">
                  {formatSolarTime(solarTimes.sunset)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- WIDGET 2x2 COMPACT GLAZE ---------------- */}
        {size === '2x2' && (
          <div
            className="w-64 h-64 rounded-[32px] p-5 border transition-all duration-700 shadow-2xl flex flex-col justify-between backdrop-blur-2xl relative overflow-hidden"
            style={{
              background: widgetColors.bg,
              borderColor: widgetColors.border,
            }}
          >
            <div className="flex items-center justify-between relative z-10">
              <span className="text-xs font-bold text-white font-display">Spunky Sun</span>
              <span
                className="text-[10px] font-mono-numbers px-2.5 py-0.5 rounded-full font-bold border"
                style={{
                  backgroundColor: `${widgetColors.accent}20`,
                  borderColor: `${widgetColors.accent}40`,
                  color: widgetColors.accent,
                }}
              >
                {solarPosition.elevation >= 0 ? `+${solarPosition.elevation.toFixed(1)}°` : `${solarPosition.elevation.toFixed(1)}°`}
              </span>
            </div>

            <div className="flex flex-col items-center justify-center my-auto relative z-10">
              <div
                className="w-16 h-16 rounded-3xl flex items-center justify-center mb-2 shadow-inner transition-colors duration-500"
                style={{ backgroundColor: `${widgetColors.accent}25` }}
              >
                {solarPosition.elevation >= 0 ? (
                  <Sun className="w-8 h-8" style={{ color: widgetColors.sunColor }} />
                ) : (
                  <Moon className="w-8 h-8 text-indigo-300" />
                )}
              </div>
              <span className="text-xs font-bold text-white text-center">
                {isGoldenActive ? 'Golden Hour Active' : currentPhaseInfo.name}
              </span>
              <span className="text-[11px] font-mono-numbers mt-0.5 font-bold" style={{ color: widgetColors.accent }}>
                {goldenCountdown}
              </span>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-300 pt-2 border-t border-white/10 relative z-10">
              <span>↑ {formatSolarTime(solarTimes.sunrise)}</span>
              <span>↓ {formatSolarTime(solarTimes.sunset)}</span>
            </div>
          </div>
        )}

        {/* ---------------- WIDGET 4x1 HORIZON STRIP ---------------- */}
        {size === '4x1' && (
          <div
            className="w-full max-w-lg rounded-[28px] px-5 py-3.5 border transition-all duration-700 shadow-2xl flex items-center justify-between gap-4 backdrop-blur-2xl"
            style={{
              background: widgetColors.bg,
              borderColor: widgetColors.border,
            }}
          >
            <div className="flex items-center gap-2 shrink-0">
              <div
                className="w-8 h-8 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${widgetColors.accent}25` }}
              >
                {solarPosition.elevation >= 0 ? (
                  <Sun className="w-4 h-4" style={{ color: widgetColors.sunColor }} />
                ) : (
                  <Moon className="w-4 h-4 text-indigo-300" />
                )}
              </div>
              <div>
                <span className="text-xs font-bold text-white block">Spunky Sun</span>
                <span className="text-[10px] text-slate-300">{location.name}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono-numbers">
              <div className="flex items-center gap-1">
                <Sunrise className="w-3.5 h-3.5 text-orange-400" />
                <span className="font-bold text-white">{formatSolarTime(solarTimes.sunrise)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" style={{ color: widgetColors.accent }} />
                <span className="font-bold" style={{ color: widgetColors.accent }}>{goldenCountdown}</span>
              </div>
              <div className="flex items-center gap-1">
                <Sunset className="w-3.5 h-3.5 text-rose-400" />
                <span className="font-bold text-white">{formatSolarTime(solarTimes.sunset)}</span>
              </div>
            </div>
          </div>
        )}

        {/* ---------------- WIDGET 2x1 GOLDEN PILL ---------------- */}
        {size === '2x1' && (
          <div
            className="w-64 rounded-[28px] px-5 py-3.5 border transition-all duration-700 shadow-2xl flex items-center justify-between backdrop-blur-2xl"
            style={{
              background: widgetColors.bg,
              borderColor: widgetColors.border,
            }}
          >
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5" style={{ color: widgetColors.accent }} />
              <div>
                <span className="text-xs font-bold text-white block">
                  {isGoldenActive ? 'Golden Hour' : currentPhaseInfo.name}
                </span>
                <span className="text-[10px] font-mono-numbers font-bold" style={{ color: widgetColors.accent }}>
                  {goldenCountdown}
                </span>
              </div>
            </div>
            <span className="text-xs font-mono-numbers text-white font-bold">
              {solarPosition.elevation >= 0 ? `+${solarPosition.elevation.toFixed(1)}°` : `${solarPosition.elevation.toFixed(1)}°`}
            </span>
          </div>
        )}
      </div>

      {/* Floating Widget Guide Note */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-300 leading-relaxed flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-white block mb-0.5">Real-Time Solar Adaptation & Floating PiP:</strong>
          As time advances throughout the day (or when you drag the 24-Hour Scrubber below), the widget's sky background, sun position along the horizon arc, lighting aura, and countdown change dynamically. Tap <strong className="text-amber-400">"Float on Screen (PiP)"</strong> to float it right over your Samsung One UI home screen!
        </div>
      </div>
    </div>
  );
};
