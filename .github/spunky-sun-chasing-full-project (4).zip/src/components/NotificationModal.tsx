import React, { useState } from 'react';
import { X, Bell, Volume2, Sparkles, Clock, Check, AlertCircle } from 'lucide-react';
import {
  NotificationSettings,
  AlertLeadTime,
  requestNotificationPermission,
  getNotificationPermission,
  triggerNotification,
  isNotificationSupported,
} from '../utils/notifications';
import { DynamicTheme } from '../utils/themeEngine';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: NotificationSettings;
  onUpdateSettings: (newSettings: NotificationSettings) => void;
  theme: DynamicTheme;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  theme,
}) => {
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>(
    getNotificationPermission()
  );
  const [testSent, setTestSent] = useState(false);

  if (!isOpen) return null;

  const supported = isNotificationSupported();

  const handleToggleMain = async () => {
    if (!settings.enabled) {
      // Trying to enable
      if (permissionStatus !== 'granted') {
        const granted = await requestNotificationPermission();
        setPermissionStatus(getNotificationPermission());
        if (!granted) {
          // User denied or dismissed
          return;
        }
      }
      onUpdateSettings({ ...settings, enabled: true });
    } else {
      onUpdateSettings({ ...settings, enabled: false });
    }
  };

  const handleTestNow = () => {
    triggerNotification(
      'Solis Test Alert',
      'Golden Hour notification test was successful. Sound chime and notification working!',
      settings.soundEnabled
    );
    setTestSent(true);
    setTimeout(() => setTestSent(false), 2500);
  };

  const leadOptions: { label: string; value: AlertLeadTime }[] = [
    { label: 'Exactly at Start', value: 0 },
    { label: '15 min Before', value: 15 },
    { label: '30 min Before', value: 30 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4 overflow-y-auto">
      <div
        className="w-full max-w-md rounded-3xl p-6 shadow-2xl border transition-all max-h-[90vh] flex flex-col my-auto"
        style={{
          backgroundColor: theme.surface,
          borderColor: theme.cardBorder,
          color: theme.textPrimary,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5" style={{ color: theme.primary }} />
            <h3 className="text-base font-bold tracking-tight font-display">Golden Hour Alerts</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close notification settings"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="py-4 space-y-5 overflow-y-auto pr-1">
          {/* Main Master Switch Card */}
          <div
            className="p-4 rounded-2xl border flex items-center justify-between"
            style={{
              backgroundColor: settings.enabled ? theme.primaryContainer : theme.surfaceContainer,
              borderColor: theme.cardBorder,
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0"
                style={{
                  backgroundColor: settings.enabled ? theme.primary : 'rgba(255,255,255,0.1)',
                  color: settings.enabled ? theme.onPrimary : theme.textPrimary,
                }}
              >
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-bold">Push Notifications</div>
                <div className="text-xs text-slate-400">
                  {settings.enabled ? 'Alerts are armed' : 'Alerts are turned off'}
                </div>
              </div>
            </div>

            <button
              onClick={handleToggleMain}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out ${
                settings.enabled ? 'bg-amber-500' : 'bg-slate-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  settings.enabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {!supported && (
            <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/10 text-amber-300 text-xs border border-amber-500/20">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Web Notifications are restricted in this environment. In-app audio and banners will still trigger.</span>
            </div>
          )}

          {supported && permissionStatus === 'denied' && (
            <div className="p-3 rounded-xl bg-rose-500/10 text-rose-300 text-xs border border-rose-500/20">
              Notifications are blocked in your browser settings. Please allow notifications in site permissions.
            </div>
          )}

          {/* Lead Time Selection */}
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400">
              <Clock className="w-3.5 h-3.5" />
              <span>Alert Timing Lead Time</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {leadOptions.map((opt) => {
                const isSelected = settings.leadTimeMinutes === opt.value;
                return (
                  <button
                    key={opt.value}
                    onClick={() => onUpdateSettings({ ...settings, leadTimeMinutes: opt.value })}
                    className={`py-2 px-2.5 rounded-xl text-xs font-medium border text-center transition-all cursor-pointer ${
                      isSelected
                        ? 'border-amber-400 font-bold shadow-sm'
                        : 'border-white/10 opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      backgroundColor: isSelected ? theme.surfaceContainerHigh : theme.surfaceContainer,
                      color: isSelected ? theme.primary : theme.textPrimary,
                    }}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Individual Phase Toggles */}
          <div className="space-y-2.5">
            <span className="text-xs font-semibold text-slate-400 block">Active Solar Alert Events</span>

            {/* Morning Golden Hour */}
            <div
              className="flex items-center justify-between p-3 rounded-2xl border"
              style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}
            >
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-medium">Morning Golden Hour</span>
              </div>
              <input
                type="checkbox"
                checked={settings.goldenHourMorning}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, goldenHourMorning: e.target.checked })
                }
                className="w-4 h-4 rounded text-amber-500 focus:ring-0 cursor-pointer"
              />
            </div>

            {/* Evening Golden Hour */}
            <div
              className="flex items-center justify-between p-3 rounded-2xl border"
              style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}
            >
              <div className="flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-medium">Evening Golden Hour</span>
              </div>
              <input
                type="checkbox"
                checked={settings.goldenHourEvening}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, goldenHourEvening: e.target.checked })
                }
                className="w-4 h-4 rounded text-amber-500 focus:ring-0 cursor-pointer"
              />
            </div>

            {/* Morning Blue Hour */}
            <div
              className="flex items-center justify-between p-3 rounded-2xl border"
              style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}
            >
              <div className="flex items-center gap-2.5">
                <span className="w-3.5 h-3.5 rounded-full bg-indigo-500 inline-block" />
                <span className="text-xs font-medium">Morning Blue Hour</span>
              </div>
              <input
                type="checkbox"
                checked={settings.blueHourMorning}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, blueHourMorning: e.target.checked })
                }
                className="w-4 h-4 rounded text-indigo-500 focus:ring-0 cursor-pointer"
              />
            </div>

            {/* Evening Blue Hour */}
            <div
              className="flex items-center justify-between p-3 rounded-2xl border"
              style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}
            >
              <div className="flex items-center gap-2.5">
                <span className="w-3.5 h-3.5 rounded-full bg-blue-500 inline-block" />
                <span className="text-xs font-medium">Evening Blue Hour</span>
              </div>
              <input
                type="checkbox"
                checked={settings.blueHourEvening}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, blueHourEvening: e.target.checked })
                }
                className="w-4 h-4 rounded text-blue-500 focus:ring-0 cursor-pointer"
              />
            </div>

            {/* Sound Chime Toggle */}
            <div
              className="flex items-center justify-between p-3 rounded-2xl border"
              style={{ backgroundColor: theme.surfaceContainer, borderColor: theme.cardBorder }}
            >
              <div className="flex items-center gap-2.5">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-xs font-medium block">Audio Chime Harmonic</span>
                  <span className="text-[10px] text-slate-400">Harmonic dual-bell chord on alert</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, soundEnabled: e.target.checked })
                }
                className="w-4 h-4 rounded text-emerald-500 focus:ring-0 cursor-pointer"
              />
            </div>
          </div>

          {/* Test Alert Button */}
          <button
            onClick={handleTestNow}
            className="w-full py-2.5 rounded-2xl text-xs font-bold border transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
            style={{
              backgroundColor: theme.surfaceContainerHigh,
              borderColor: theme.cardBorder,
              color: theme.primary,
            }}
          >
            {testSent ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Test Alert Dispatched!</span>
              </>
            ) : (
              <>
                <Bell className="w-4 h-4" />
                <span>Send Test Notification & Chime Now</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
