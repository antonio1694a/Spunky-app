import React, { useState, useEffect } from 'react';
import { WifiOff, CheckCircle2 } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3000);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (showReconnected) {
    return (
      <div className="fixed bottom-4 left-4 z-40 flex items-center gap-2 rounded-full bg-emerald-500/90 text-white px-3.5 py-1.5 text-xs font-medium backdrop-blur-md shadow-lg transition-all animate-bounce">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Back Online</span>
      </div>
    );
  }

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-40 flex items-center gap-2 rounded-full bg-amber-600/95 text-white px-3.5 py-1.5 text-xs font-medium backdrop-blur-md shadow-lg border border-amber-400/30">
      <WifiOff className="w-3.5 h-3.5 text-amber-200" />
      <span>Offline Mode — Pure NOAA Math Active</span>
    </div>
  );
};
